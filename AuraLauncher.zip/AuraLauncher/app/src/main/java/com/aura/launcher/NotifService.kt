package com.aura.launcher

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.core.app.NotificationManagerCompat

class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val intent: PendingIntent?
)

object NotifHub {
    val items = mutableStateListOf<NotifItem>()
    var service: AuraNotifService? = null
}

class AuraNotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotifHub.service = this
        refresh()
    }

    override fun onListenerDisconnected() {
        NotifHub.service = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val list = runCatching { activeNotifications }.getOrNull() ?: return
        val pm = packageManager
        val mapped = list
            .filter {
                it.packageName != packageName &&
                    !it.isOngoing &&
                    (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
            }
            .map { sbn ->
                val ex = sbn.notification.extras
                val appName = runCatching {
                    pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                }.getOrDefault(sbn.packageName)
                NotifItem(
                    key = sbn.key,
                    pkg = sbn.packageName,
                    app = appName,
                    title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
                    text = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
                    time = sbn.postTime,
                    intent = sbn.notification.contentIntent
                )
            }
            .sortedByDescending { it.time }
        NotifHub.items.clear()
        NotifHub.items.addAll(mapped)
    }
}

fun notifAccessEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

fun openNotifAccess(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(
            ctx,
            "Esta TV não tem essa tela. Use via ADB: adb shell cmd notification allow_listener " +
                "${ctx.packageName}/${ctx.packageName}.AuraNotifService",
            Toast.LENGTH_LONG
        ).show()
    }
}
