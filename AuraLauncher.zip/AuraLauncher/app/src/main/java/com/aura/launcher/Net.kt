package com.aura.launcher

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

object Net {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "AuraLauncher/1.0")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Temperatura (°C) e código WMO, via Open-Meteo (gratuito, sem chave). */
    suspend fun weather(lat: Double, lon: Double): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        runCatching {
            val j = JSONObject(
                get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")
            ).getJSONObject("current")
            Pair(j.getDouble("temperature_2m").roundToInt(), j.getInt("weather_code"))
        }.getOrNull()
    }

    suspend fun geocode(name: String): Triple<String, Double, Double>? = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(name, "UTF-8")
            val r = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=pt"))
                .getJSONArray("results").getJSONObject(0)
            Triple(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
        }.getOrNull()
    }

    /** Títulos de um feed RSS ou Atom. */
    suspend fun rss(url: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val xml = get(url)
            val p = Xml.newPullParser()
            p.setInput(StringReader(xml))
            val titles = mutableListOf<String>()
            var inEntry = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && titles.size < 20) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "item", "entry" -> inEntry = true
                        "title" -> if (inEntry) {
                            val t = p.nextText().trim()
                            if (t.isNotEmpty()) titles.add(t)
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry")) {
                    inEntry = false
                }
                ev = p.next()
            }
            titles
        }.getOrDefault(emptyList())
    }

    /** Imagens de fundo (backdrops) de filmes em alta. Precisa de chave gratuita do TMDB. */
    suspend fun posters(key: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val arr = JSONObject(
                get("https://api.themoviedb.org/3/trending/movie/week?api_key=$key&language=pt-BR")
            ).getJSONArray("results")
            (0 until arr.length()).mapNotNull {
                val path = arr.getJSONObject(it).optString("backdrop_path", "")
                if (path.isNotEmpty() && path != "null") "https://image.tmdb.org/t/p/w1280$path" else null
            }
        }.getOrDefault(emptyList())
    }
}

fun weatherEmoji(code: Int): String = when (code) {
    0 -> "☀️"
    1, 2 -> "🌤️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..67 -> "🌧️"
    in 71..77 -> "❄️"
    in 80..82 -> "🌦️"
    in 95..99 -> "⛈️"
    else -> "🌡️"
}
