package com.aura.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private class Particle(val x: Float, val phase: Float, val speed: Int, val size: Float)

/**
 * Efeitos climáticos desenhados sobre a tela inicial.
 * kind: rain | snow | storm
 */
@Composable
fun WeatherFx(kind: String, intensity: Int) {
    val snow = kind == "snow"
    val mult = when (intensity) {
        1 -> 0.5f
        3 -> 1.7f
        else -> 1f
    }
    val count = ((if (snow) 70 else 110) * mult).toInt()
    val particles = remember(kind, count) {
        val r = Random(7)
        List(count) { Particle(r.nextFloat(), r.nextFloat(), 1 + r.nextInt(3), 0.5f + r.nextFloat()) }
    }
    val duration = if (snow) 14000 else 2500
    val t by rememberInfiniteTransition(label = "fx").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(duration, easing = LinearEasing), RepeatMode.Restart),
        label = "fxT"
    )
    val flash = remember { Animatable(0f) }
    if (kind == "storm") {
        LaunchedEffect(Unit) {
            while (true) {
                delay(Random.nextLong(4000L, 10000L))
                flash.snapTo(0.75f)
                flash.animateTo(0f, tween(180))
                delay(110)
                flash.snapTo(0.55f)
                flash.animateTo(0f, tween(450))
            }
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (snow) {
            particles.forEach { s ->
                val prog = t * s.speed + s.phase
                val y = (prog % 1f) * (h + 20f) - 10f
                val x = s.x * w + sin(prog * 2f * PI.toFloat() * 2f) * 24f
                drawCircle(
                    color = Color.White.copy(alpha = 0.45f + 0.3f * (s.size - 0.5f)),
                    radius = 2.5f + 3.5f * s.size,
                    center = Offset(x, y)
                )
            }
        } else {
            val len = if (kind == "storm") 34f else 26f
            val alpha = if (kind == "storm") 0.55f else 0.42f
            particles.forEach { s ->
                val prog = t * s.speed + s.phase
                val y = (prog % 1f) * (h + len) - len
                val x = (s.x * w + (y / h) * 60f) % w
                drawLine(
                    color = Color(0xFFBFD7FF).copy(alpha = alpha),
                    start = Offset(x - 7f, y - len),
                    end = Offset(x, y),
                    strokeWidth = 1.5f + 1.2f * s.size
                )
            }
        }
        if (flash.value > 0f) {
            drawRect(Color.White.copy(alpha = flash.value))
        }
    }
}
