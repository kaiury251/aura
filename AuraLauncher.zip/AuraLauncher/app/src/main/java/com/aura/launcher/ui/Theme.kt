package com.aura.launcher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.unit.dp

@Composable
fun AuraTheme(accent: Color, content: @Composable () -> Unit) {
    val base = Color(0xFF121212)
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = onAccent,
        secondary = lerp(accent, Color.White, 0.3f),
        surface = lerp(base, accent, 0.10f),
        surfaceVariant = lerp(base, accent, 0.22f),
        background = lerp(base, accent, 0.08f),
        secondaryContainer = lerp(base, accent, 0.35f),
        onSurface = Color.White,
        onSurfaceVariant = Color(0xFFDDDDDD),
        onSecondaryContainer = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

/**
 * Caixa focável para controle remoto: cresce e ganha borda quando recebe foco.
 * Clique longo (ou tecla Menu) chama [onLongClick].
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusBox(
    modifier: Modifier = Modifier,
    shape: Shape,
    scale: Float = 1.08f,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val s by animateFloatAsState(if (focused) scale else 1f, label = "focusScale")
    Box(
        modifier = Modifier
            .scale(s)
            .border(if (focused) 3.dp else 0.dp, Color.White.copy(alpha = 0.9f), shape)
            .clip(shape)
            .then(modifier)
            .onKeyEvent {
                if (onLongClick != null && it.type == KeyEventType.KeyUp && it.key == Key.Menu) {
                    onLongClick(); true
                } else false
            }
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            ),
        content = content
    )
}
