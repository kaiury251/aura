package com.aura.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.isSystemInDarkTheme
import android.os.Build
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val LocalGlass = compositionLocalOf { false }

/** Fontes do sistema oferecidas nos ajustes: valor -> nome exibido. */
val FONT_OPTIONS = listOf(
    "default" to "Padrão do sistema",
    "sans" to "Sans-serif",
    "light" to "Sans-serif leve",
    "thin" to "Sans-serif fina",
    "medium" to "Sans-serif média",
    "black" to "Sans-serif negrito forte",
    "condensed" to "Condensada",
    "serif" to "Serifada",
    "mono" to "Monoespaçada",
    "casual" to "Casual",
    "cursive" to "Cursiva"
)

private fun sys(name: String): FontFamily =
    FontFamily(android.graphics.Typeface.create(name, android.graphics.Typeface.NORMAL))

fun fontFamilyFor(name: String): FontFamily = when (name) {
    "sans" -> FontFamily.SansSerif
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    "light" -> sys("sans-serif-light")
    "thin" -> sys("sans-serif-thin")
    "condensed" -> sys("sans-serif-condensed")
    "medium" -> sys("sans-serif-medium")
    "black" -> sys("sans-serif-black")
    "casual" -> sys("casual")
    else -> FontFamily.Default
}

private fun typographyFor(ff: FontFamily): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = ff),
        displayMedium = d.displayMedium.copy(fontFamily = ff),
        displaySmall = d.displaySmall.copy(fontFamily = ff),
        headlineLarge = d.headlineLarge.copy(fontFamily = ff),
        headlineMedium = d.headlineMedium.copy(fontFamily = ff),
        headlineSmall = d.headlineSmall.copy(fontFamily = ff),
        titleLarge = d.titleLarge.copy(fontFamily = ff),
        titleMedium = d.titleMedium.copy(fontFamily = ff),
        titleSmall = d.titleSmall.copy(fontFamily = ff),
        bodyLarge = d.bodyLarge.copy(fontFamily = ff),
        bodyMedium = d.bodyMedium.copy(fontFamily = ff),
        bodySmall = d.bodySmall.copy(fontFamily = ff),
        labelLarge = d.labelLarge.copy(fontFamily = ff),
        labelMedium = d.labelMedium.copy(fontFamily = ff),
        labelSmall = d.labelSmall.copy(fontFamily = ff)
    )
}

@Composable
fun AuraTheme(accent: Color, glass: Boolean, font: String, mode: String = "dark", dynamic: Boolean = false, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val light = mode == "light" || (mode == "system" && !isSystemInDarkTheme())
    val oled = mode == "oled"
    val systemMode = mode == "system"
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= 31 && (light || systemMode) -> dynamicLightColorScheme(context)
        dynamic && Build.VERSION.SDK_INT >= 31 -> dynamicDarkColorScheme(context)
        light -> lightColorScheme(primary = accent, secondary = lerp(accent, Color.Black, 0.18f), surface = Color(0xFFF7F7F7), background = Color(0xFFF7F7F7))
        oled -> darkColorScheme(primary = accent, secondary = lerp(accent, Color.White, 0.3f), surface = Color.Black, background = Color.Black, surfaceVariant = Color(0xFF080808), onSurface = Color.White, onSurfaceVariant = Color(0xFFDDDDDD))
        else -> {
            val base = Color(0xFF121212)
            val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
            darkColorScheme(primary = accent, onPrimary = onAccent, secondary = lerp(accent, Color.White, 0.3f), surface = lerp(base, accent, 0.10f), surfaceVariant = lerp(base, accent, 0.22f), background = lerp(base, accent, 0.08f), secondaryContainer = lerp(base, accent, 0.35f), onSurface = Color.White, onSurfaceVariant = Color(0xFFDDDDDD), onSecondaryContainer = Color.White)
        }
    }
    val typo = remember(font) { typographyFor(fontFamilyFor(font)) }
    CompositionLocalProvider(LocalGlass provides glass) { MaterialTheme(colorScheme = scheme, typography = typo, content = content) }
}

/** Estilo padrão de painéis e botões conforme a aparência escolhida. */
@Composable
fun panelStyle(): String = if (LocalGlass.current) "glass" else "solid"

/** Texto lido diretamente sobre o papel de parede ganha uma sombra leve. */
@Composable
fun shadowed(): TextStyle = LocalTextStyle.current.copy(
    shadow = Shadow(Color.Black.copy(alpha = 0.75f), Offset(0f, 2f), 6f)
)

private val GlassFill = listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.07f))
private val GlassEdge = listOf(
    Color.White.copy(alpha = 0.65f),
    Color.White.copy(alpha = 0.08f),
    Color.White.copy(alpha = 0.35f)
)

/**
 * Caixa focável para controle remoto: cresce e ganha borda quando recebe foco.
 * style: solid | glass | clear | accent. Clique longo (ou tecla Menu) chama [onLongClick].
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusBox(
    modifier: Modifier = Modifier,
    shape: Shape,
    scale: Float = 1.08f,
    style: String = "solid",
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val s by animateFloatAsState(if (focused) scale else 1f, label = "focusScale")
    val cs = MaterialTheme.colorScheme
    val bg = when (style) {
        "glass" -> Modifier.background(Brush.verticalGradient(GlassFill))
        "accent" -> Modifier.background(cs.primary.copy(alpha = 0.9f))
        "clear" -> Modifier
        else -> Modifier.background(cs.surfaceVariant)
    }
    val edge = when {
        focused -> Modifier.border(3.dp, Color.White.copy(alpha = 0.9f), shape)
        style == "glass" -> Modifier.border(1.dp, Brush.linearGradient(GlassEdge), shape)
        else -> Modifier
    }
    Box(
        modifier = Modifier
            .scale(s)
            .then(edge)
            .clip(shape)
            .then(bg)
            .then(modifier)
            .onKeyEvent {
                if (onLongClick != null && it.type == KeyEventType.KeyUp && it.key == Key.Menu) {
                    onLongClick(); true
                } else false
            }
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            ),
        content = content
    )
}

/** Cartão usado pelos diálogos. */
@Composable
fun PanelCard(title: String, width: Dp = 520.dp, content: @Composable ColumnScope.() -> Unit) {
    val glass = LocalGlass.current
    val shape = RoundedCornerShape(20.dp)
    val bg = if (glass) {
        Modifier
            .background(Color.Black.copy(alpha = 0.5f), shape)
            .background(Brush.verticalGradient(GlassFill), shape)
            .border(1.dp, Brush.linearGradient(GlassEdge), shape)
    } else {
        Modifier.background(MaterialTheme.colorScheme.surface, shape)
    }
    Column(
        Modifier
            .width(width)
            .then(bg)
            .padding(24.dp)
    ) {
        Text(title, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(14.dp))
        content()
    }
}
