package com.aura.launcher

import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class AppItem(val pkg: String, val label: String, val intent: Intent)

data class InputItem(val id: String, val label: String)

data class Folder(val name: String, val pkgs: List<String>)

data class Profile(
    val name: String = "Perfil",
    val pin: String = "",
    val favorites: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    val folders: List<Folder> = emptyList(),
    val customNames: Map<String, String> = emptyMap(),
    val customIcons: Map<String, String> = emptyMap(),
    val wallType: String = "color", // color | image | video | poster
    val wallUri: String = "",
    val tmdbKey: String = "",
    val dim: Float = 0.35f,
    val dynamic: Boolean = true,
    val accent: Int = 0xFF7C5CFF.toInt(),
    val anim: String = "zoom", // none | fade | zoom | slide
    val focusScale: Float = 1.12f,
    val idleFade: Int = 0, // segundos, 0 = desligado
    val showClock: Boolean = true,
    val showWeather: Boolean = false,
    val city: String = "São Paulo",
    val lat: Double = -23.55,
    val lon: Double = -46.63,
    val showRss: Boolean = false,
    val rssUrl: String = "",
    val showInputs: Boolean = true,
    val autostart: String = ""
)

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

private fun JSONObject.stringMap(): Map<String, String> =
    keys().asSequence().associateWith { getString(it) }

private fun Map<String, String>.toJsonObj(): JSONObject {
    val o = JSONObject()
    forEach { (k, v) -> o.put(k, v) }
    return o
}

fun Profile.toJson(): JSONObject = JSONObject().apply {
    put("name", name)
    put("pin", pin)
    put("favorites", JSONArray(favorites))
    put("hidden", JSONArray(hidden.toList()))
    put("folders", JSONArray().also { arr ->
        folders.forEach { f ->
            arr.put(JSONObject().put("n", f.name).put("p", JSONArray(f.pkgs)))
        }
    })
    put("customNames", customNames.toJsonObj())
    put("customIcons", customIcons.toJsonObj())
    put("wallType", wallType)
    put("wallUri", wallUri)
    put("tmdbKey", tmdbKey)
    put("dim", dim.toDouble())
    put("dynamic", dynamic)
    put("accent", accent)
    put("anim", anim)
    put("focusScale", focusScale.toDouble())
    put("idleFade", idleFade)
    put("showClock", showClock)
    put("showWeather", showWeather)
    put("city", city)
    put("lat", lat)
    put("lon", lon)
    put("showRss", showRss)
    put("rssUrl", rssUrl)
    put("showInputs", showInputs)
    put("autostart", autostart)
}

fun profileFromJson(o: JSONObject): Profile {
    val d = Profile()
    val folders = o.optJSONArray("folders")?.let { arr ->
        (0 until arr.length()).map {
            val f = arr.getJSONObject(it)
            Folder(f.optString("n"), f.optJSONArray("p")?.strings() ?: emptyList())
        }
    } ?: emptyList()
    return Profile(
        name = o.optString("name", d.name),
        pin = o.optString("pin", d.pin),
        favorites = o.optJSONArray("favorites")?.strings() ?: emptyList(),
        hidden = o.optJSONArray("hidden")?.strings()?.toSet() ?: emptySet(),
        folders = folders,
        customNames = o.optJSONObject("customNames")?.stringMap() ?: emptyMap(),
        customIcons = o.optJSONObject("customIcons")?.stringMap() ?: emptyMap(),
        wallType = o.optString("wallType", d.wallType),
        wallUri = o.optString("wallUri", d.wallUri),
        tmdbKey = o.optString("tmdbKey", d.tmdbKey),
        dim = o.optDouble("dim", d.dim.toDouble()).toFloat(),
        dynamic = o.optBoolean("dynamic", d.dynamic),
        accent = o.optInt("accent", d.accent),
        anim = o.optString("anim", d.anim),
        focusScale = o.optDouble("focusScale", d.focusScale.toDouble()).toFloat(),
        idleFade = o.optInt("idleFade", d.idleFade),
        showClock = o.optBoolean("showClock", d.showClock),
        showWeather = o.optBoolean("showWeather", d.showWeather),
        city = o.optString("city", d.city),
        lat = o.optDouble("lat", d.lat),
        lon = o.optDouble("lon", d.lon),
        showRss = o.optBoolean("showRss", d.showRss),
        rssUrl = o.optString("rssUrl", d.rssUrl),
        showInputs = o.optBoolean("showInputs", d.showInputs),
        autostart = o.optString("autostart", d.autostart)
    )
}
