package com.aura.launcher

import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class AppItem(val pkg: String, val label: String, val intent: Intent)

data class InputItem(val id: String, val label: String)

data class Folder(val name: String, val pkgs: List<String>)

data class Profile(
    val name: String = "Perfil",
    val pin: String = "",
    val avatar: String = "",
    val favorites: List<String> = emptyList(),
    val appOrder: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    val folders: List<Folder> = emptyList(),
    val customNames: Map<String, String> = emptyMap(),
    val customIcons: Map<String, String> = emptyMap(),
    // Papel de parede
    val wallType: String = "color", // color | image | video | poster
    val wallUri: String = "",
    val tmdbKey: String = "",
    val dim: Float = 0.35f,
    val blur: Int = 0, // 0..25
    val brightness: Float = 1f, // 0.6..1.4
    // Efeitos climáticos
    val fxMode: String = "off", // off | auto | rain | snow | storm
    val fxIntensity: Int = 2, // 1..3
    // Aparência
    val glass: Boolean = false,
    val font: String = "default",
    val dynamic: Boolean = true,
    val themeMode: String = "dark", // system | dark | light | oled
    val gridColumns: Int = 6, // 4..8
    val gridSpacing: Int = 16, // dp spacing preset
    val gridAlign: String = "top", // top | bottom
    val accent: Int = 0xFF7C5CFF.toInt(),
    // Blocos de apps
    val tileStyle: String = "solid", // solid | clear | accent | glass
    val iconShape: String = "banner", // banner | rounded | circle | square
    val iconSize: Int = 1, // 0 pequeno, 1 médio, 2 grande
    val iconMono: Boolean = false,
    val iconPack: String = "",
    val appSizes: Map<String, String> = emptyMap(),
    val appShapes: Map<String, String> = emptyMap(),
    val appPin: String = "",
    val locked: Set<String> = emptySet(),
    // Animações
    val anim: String = "zoom", // none | fade | zoom | slide
    val focusScale: Float = 1.12f,
    val idleFade: Int = 0, // segundos, 0 = desligado
    // Widgets
    val showClock: Boolean = true,
    val showDate: Boolean = true,
    val showWeather: Boolean = false,
    val city: String = "São Paulo",
    val lat: Double = -23.55,
    val lon: Double = -46.63,
    val showNetwork: Boolean = false,
    val showNowPlaying: Boolean = false,
    val showRss: Boolean = false,
    val rssUrl: String = "",
    val showInputs: Boolean = true,
    val showBell: Boolean = true,
    val showBluetooth: Boolean = true,
    val autostart: String = ""
)

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

private fun JSONObject.stringMap(): Map<String, String> =
    keys().asSequence().associateWith { getString(it) }

private fun Map<String, String>.toJsonObj(): JSONObject {
    val o = JSONObject()
    forEach { (k, v) -> o.put(k, v) }
    return o
}

fun Profile.toJson(): JSONObject = JSONObject().apply {
    put("name", name)
    put("pin", pin)
    put("avatar", avatar)
    put("favorites", JSONArray(favorites))
    put("appOrder", JSONArray(appOrder))
    put("hidden", JSONArray(hidden.toList()))
    put("folders", JSONArray().also { arr ->
        folders.forEach { f ->
            arr.put(JSONObject().put("n", f.name).put("p", JSONArray(f.pkgs)))
        }
    })
    put("customNames", customNames.toJsonObj())
    put("customIcons", customIcons.toJsonObj())
    put("wallType", wallType)
    put("wallUri", wallUri)
    put("tmdbKey", tmdbKey)
    put("dim", dim.toDouble())
    put("blur", blur)
    put("brightness", brightness.toDouble())
    put("fxMode", fxMode)
    put("fxIntensity", fxIntensity)
    put("glass", glass)
    put("font", font)
    put("dynamic", dynamic)
    put("themeMode", themeMode)
    put("gridColumns", gridColumns)
    put("gridSpacing", gridSpacing)
    put("gridAlign", gridAlign)
    put("accent", accent)
    put("tileStyle", tileStyle)
    put("iconShape", iconShape)
    put("iconSize", iconSize)
    put("iconMono", iconMono)
    put("iconPack", iconPack)
    put("appSizes", appSizes.toJsonObj())
    put("appShapes", appShapes.toJsonObj())
    put("appPin", appPin)
    put("locked", JSONArray(locked.toList()))
    put("anim", anim)
    put("focusScale", focusScale.toDouble())
    put("idleFade", idleFade)
    put("showClock", showClock)
    put("showDate", showDate)
    put("showWeather", showWeather)
    put("city", city)
    put("lat", lat)
    put("lon", lon)
    put("showNetwork", showNetwork)
    put("showNowPlaying", showNowPlaying)
    put("showRss", showRss)
    put("rssUrl", rssUrl)
    put("showInputs", showInputs)
    put("showBell", showBell)
    put("showBluetooth", showBluetooth)
    put("autostart", autostart)
}

fun profileFromJson(o: JSONObject): Profile {
    val d = Profile()
    val folders = o.optJSONArray("folders")?.let { arr ->
        (0 until arr.length()).map {
            val f = arr.getJSONObject(it)
            Folder(f.optString("n"), f.optJSONArray("p")?.strings() ?: emptyList())
        }
    } ?: emptyList()
    return Profile(
        name = o.optString("name", d.name),
        pin = o.optString("pin", d.pin),
        avatar = o.optString("avatar", d.avatar),
        favorites = o.optJSONArray("favorites")?.strings() ?: emptyList(),
        appOrder = o.optJSONArray("appOrder")?.strings() ?: emptyList(),
        hidden = o.optJSONArray("hidden")?.strings()?.toSet() ?: emptySet(),
        folders = folders,
        customNames = o.optJSONObject("customNames")?.stringMap() ?: emptyMap(),
        customIcons = o.optJSONObject("customIcons")?.stringMap() ?: emptyMap(),
        wallType = o.optString("wallType", d.wallType),
        wallUri = o.optString("wallUri", d.wallUri),
        tmdbKey = o.optString("tmdbKey", d.tmdbKey),
        dim = o.optDouble("dim", d.dim.toDouble()).toFloat(),
        blur = o.optInt("blur", d.blur),
        brightness = o.optDouble("brightness", d.brightness.toDouble()).toFloat(),
        fxMode = o.optString("fxMode", d.fxMode),
        fxIntensity = o.optInt("fxIntensity", d.fxIntensity),
        glass = o.optBoolean("glass", d.glass),
        font = o.optString("font", d.font),
        dynamic = o.optBoolean("dynamic", d.dynamic),
        themeMode = o.optString("themeMode", d.themeMode),
        gridColumns = o.optInt("gridColumns", d.gridColumns).coerceIn(4, 8),
        gridSpacing = o.optInt("gridSpacing", d.gridSpacing).coerceIn(8, 32),
        gridAlign = o.optString("gridAlign", d.gridAlign),
        accent = o.optInt("accent", d.accent),
        tileStyle = o.optString("tileStyle", d.tileStyle),
        iconShape = o.optString("iconShape", d.iconShape),
        iconSize = o.optInt("iconSize", d.iconSize),
        iconMono = o.optBoolean("iconMono", d.iconMono),
        iconPack = o.optString("iconPack", d.iconPack),
        appSizes = o.optJSONObject("appSizes")?.stringMap() ?: emptyMap(),
        appShapes = o.optJSONObject("appShapes")?.stringMap() ?: emptyMap(),
        appPin = o.optString("appPin", d.appPin),
        locked = o.optJSONArray("locked")?.strings()?.toSet() ?: emptySet(),
        anim = o.optString("anim", d.anim),
        focusScale = o.optDouble("focusScale", d.focusScale.toDouble()).toFloat(),
        idleFade = o.optInt("idleFade", d.idleFade),
        showClock = o.optBoolean("showClock", d.showClock),
        showDate = o.optBoolean("showDate", d.showDate),
        showWeather = o.optBoolean("showWeather", d.showWeather),
        city = o.optString("city", d.city),
        lat = o.optDouble("lat", d.lat),
        lon = o.optDouble("lon", d.lon),
        showNetwork = o.optBoolean("showNetwork", d.showNetwork),
        showNowPlaying = o.optBoolean("showNowPlaying", d.showNowPlaying),
        showRss = o.optBoolean("showRss", d.showRss),
        rssUrl = o.optString("rssUrl", d.rssUrl),
        showInputs = o.optBoolean("showInputs", d.showInputs),
        showBell = o.optBoolean("showBell", d.showBell),
        showBluetooth = o.optBoolean("showBluetooth", d.showBluetooth),
        autostart = o.optString("autostart", d.autostart)
    )
}
