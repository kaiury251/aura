package com.aura.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aura.launcher.Actions
import com.aura.launcher.AppItem
import com.aura.launcher.HomeViewModel

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .width(520.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
            .padding(24.dp)
    ) {
        Text(title, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
fun MenuRow(text: String, onClick: () -> Unit) {
    FocusBox(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant),
        RoundedCornerShape(12.dp),
        1.02f,
        onClick = onClick
    ) {
        Text(
            text,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
    }
}

@Composable
fun Dialogs(vm: HomeViewModel, actions: Actions) {
    val ctx = LocalContext.current
    val p = vm.profile

    // ---- Menu do app ----
    vm.menuApp?.let { app ->
        Dialog(onDismissRequest = { vm.menuApp = null }) {
            Card(vm.labelOf(app)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MenuRow("Abrir") { vm.menuApp = null; launchApp(ctx, app, p.anim) }
                    MenuRow(if (app.pkg in p.favorites) "Remover dos favoritos" else "Adicionar aos favoritos") {
                        vm.toggleFavorite(app.pkg); vm.menuApp = null
                    }
                    MenuRow("Mover para pasta…") { vm.folderPickApp = app; vm.menuApp = null }
                    MenuRow("Renomear") {
                        vm.menuApp = null
                        vm.prompt = com.aura.launcher.TextPrompt("Novo nome (vazio = original)", p.customNames[app.pkg] ?: app.label) {
                            vm.renameApp(app.pkg, it)
                        }
                    }
                    MenuRow("Ícone personalizado (imagem)") { vm.menuApp = null; actions.pickIcon(app.pkg) }
                    if (p.customIcons.containsKey(app.pkg)) {
                        MenuRow("Restaurar ícone original") { vm.setCustomIcon(app.pkg, null); vm.menuApp = null }
                    }
                    MenuRow("Ocultar") { vm.toggleHidden(app.pkg); vm.menuApp = null }
                    MenuRow("Informações do app") {
                        vm.menuApp = null
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    MenuRow("Desinstalar") {
                        vm.menuApp = null
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        }
    }

    // ---- Escolher pasta ----
    vm.folderPickApp?.let { app ->
        Dialog(onDismissRequest = { vm.folderPickApp = null }) {
            Card("Mover ${vm.labelOf(app)} para…") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    p.folders.forEachIndexed { i, f ->
                        MenuRow(f.name) { vm.addToFolder(i, app.pkg); vm.folderPickApp = null }
                    }
                    MenuRow("+ Nova pasta") {
                        vm.folderPickApp = null
                        vm.prompt = com.aura.launcher.TextPrompt("Nome da pasta") { name ->
                            if (name.isNotBlank()) vm.addFolder(name.trim(), app.pkg)
                        }
                    }
                }
            }
        }
    }

    // ---- Pasta aberta ----
    vm.openFolder?.let { idx ->
        val folder = p.folders.getOrNull(idx)
        if (folder == null) {
            vm.openFolder = null
        } else {
            Dialog(onDismissRequest = { vm.openFolder = null }) {
                Column(
                    Modifier
                        .width(760.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
                        .padding(24.dp)
                ) {
                    Text(folder.name, fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(12.dp))
                    val apps = folder.pkgs.mapNotNull { vm.appByPkg(it) }
                    if (apps.isEmpty()) {
                        Text("Pasta vazia. Segure um app e use \"Mover para pasta…\".", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.height(260.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(apps, key = { it.pkg }) { a -> AppTile(vm, a) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            vm.prompt = com.aura.launcher.TextPrompt("Renomear pasta", folder.name) { vm.renameFolder(idx, it) }
                        }) { Text("Renomear") }
                        TextButton(onClick = {
                            vm.appPicker = { a -> vm.addToFolder(idx, a.pkg) }
                        }) { Text("Adicionar app") }
                        if (apps.isNotEmpty()) {
                            TextButton(onClick = {
                                vm.appPicker = { a -> vm.removeFromFolder(idx, a.pkg) }
                            }) { Text("Remover app") }
                        }
                        TextButton(onClick = { vm.deleteFolder(idx); vm.openFolder = null }) { Text("Excluir pasta") }
                    }
                }
            }
        }
    }

    // ---- Seletor de app ----
    vm.appPicker?.let { onPick ->
        Dialog(onDismissRequest = { vm.appPicker = null }) {
            Card("Escolha um app") {
                LazyColumn(Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.allApps, key = { it.pkg }) { a ->
                        MenuRow(vm.labelOf(a)) { vm.appPicker = null; onPick(a) }
                    }
                }
            }
        }
    }

    // ---- Gerenciar apps ocultos ----
    if (vm.hiddenManager) {
        Dialog(onDismissRequest = { vm.hiddenManager = false }) {
            Card("Apps ocultos") {
                LazyColumn(Modifier.height(380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.allApps, key = { it.pkg }) { a ->
                        val hidden = a.pkg in p.hidden
                        MenuRow((if (hidden) "🙈  " else "👁  ") + vm.labelOf(a)) { vm.toggleHidden(a.pkg) }
                    }
                }
            }
        }
    }

    // ---- Prompt de texto ----
    vm.prompt?.let { pr ->
        var text by remember(pr) { mutableStateOf(pr.initial) }
        AlertDialog(
            onDismissRequest = { vm.prompt = null },
            title = { Text(pr.title) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = if (pr.numeric) KeyboardType.NumberPassword else KeyboardType.Text)
                )
            },
            confirmButton = { TextButton(onClick = { vm.prompt = null; pr.onOk(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { vm.prompt = null }) { Text("Cancelar") } }
        )
    }

    // ---- PIN ----
    vm.pinTarget?.let { target ->
        PinDialog(
            title = "PIN de ${vm.profiles[target].name}",
            onResult = { entered ->
                if (entered == vm.profiles[target].pin) {
                    vm.pinTarget = null
                    vm.switchProfile(target)
                    true
                } else false
            },
            onDismiss = { vm.pinTarget = null }
        )
    }
}

@Composable
private fun PinDialog(title: String, onResult: (String) -> Boolean, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Card(title) {
            Text(
                "•".repeat(pin.length).ifEmpty { " " },
                fontSize = 30.sp,
                color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(10.dp))
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK")
            keys.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { k ->
                        FocusBox(
                            Modifier
                                .weight(1f)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            RoundedCornerShape(12.dp),
                            1.05f,
                            onClick = {
                                error = false
                                when (k) {
                                    "⌫" -> pin = pin.dropLast(1)
                                    "OK" -> if (!onResult(pin)) { error = true; pin = "" }
                                    else -> if (pin.length < 8) pin += k
                                }
                            }
                        ) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                Text(k, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }
    }
}
