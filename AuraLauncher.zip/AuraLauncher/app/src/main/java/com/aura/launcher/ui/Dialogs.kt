package com.aura.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aura.launcher.Actions
import com.aura.launcher.AppItem
import com.aura.launcher.ChoiceRequest
import com.aura.launcher.HomeViewModel
import com.aura.launcher.PinRequest
import com.aura.launcher.TextPrompt

@Composable
fun MenuRow(text: String, fontFamily: FontFamily? = null, onClick: () -> Unit) {
    FocusBox(
        Modifier.fillMaxWidth(),
        RoundedCornerShape(12.dp),
        1.02f,
        style = panelStyle(),
        onClick = onClick
    ) {
        Text(
            text,
            fontSize = 16.sp,
            fontFamily = fontFamily,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
    }
}

private val SHAPE_OPTIONS = listOf(
    "" to "Padrão do launcher",
    "banner" to "Banner (retangular)",
    "rounded" to "Quadrado arredondado",
    "circle" to "Redondo",
    "square" to "Quadrado"
)

private val SIZE_OPTIONS = listOf(
    "" to "Padrão do launcher",
    "1.0" to "Normal (100%)",
    "0.85" to "Médio (85%)",
    "0.7" to "Pequeno (70%)"
)

@Composable
fun Dialogs(vm: HomeViewModel, actions: Actions) {
    val ctx = LocalContext.current
    val p = vm.profile

    // ---- Menu do app ----
    vm.menuApp?.let { app ->
        Dialog(onDismissRequest = { vm.menuApp = null }) {
            PanelCard(vm.labelOf(app)) {
                val rows = buildList<Pair<String, () -> Unit>> {
                    add("Abrir" to { vm.menuApp = null; openApp(vm, ctx, app) })
                    add(
                        (if (app.pkg in p.favorites) "Remover dos favoritos" else "Adicionar aos favoritos") to {
                            vm.toggleFavorite(app.pkg); vm.menuApp = null
                        }
                    )
                    add("Mover para pasta…" to { vm.folderPickApp = app; vm.menuApp = null })
                    add("Renomear" to {
                        vm.menuApp = null
                        vm.prompt = TextPrompt("Novo nome (vazio = original)", p.customNames[app.pkg] ?: app.label) {
                            vm.renameApp(app.pkg, it)
                        }
                    })
                    add("Ícone personalizado (imagem)" to { vm.menuApp = null; actions.pickIcon(app.pkg) })
                    if (p.customIcons.containsKey(app.pkg)) {
                        add("Restaurar ícone original" to { vm.setCustomIcon(app.pkg, null); vm.menuApp = null })
                    }
                    add("Formato do ícone…" to {
                        vm.menuApp = null
                        vm.choice = ChoiceRequest("Formato de ${vm.labelOf(app)}", SHAPE_OPTIONS) { v ->
                            vm.setAppShape(app.pkg, v)
                        }
                    })
                    add("Tamanho do ícone…" to {
                        vm.menuApp = null
                        vm.choice = ChoiceRequest("Tamanho de ${vm.labelOf(app)}", SIZE_OPTIONS) { v ->
                            vm.setAppSize(app.pkg, v)
                        }
                    })
                    if (app.pkg in p.locked) {
                        add("Remover bloqueio por PIN" to { vm.toggleLocked(app.pkg); vm.menuApp = null })
                    } else {
                        add("Bloquear com PIN" to {
                            vm.menuApp = null
                            if (p.appPin.isEmpty()) {
                                vm.prompt = TextPrompt("Defina o PIN dos apps bloqueados (4 a 8 números)", "", numeric = true) { raw ->
                                    val pin = raw.filter(Char::isDigit)
                                    if (pin.length >= 4) {
                                        vm.update { it.copy(appPin = pin) }
                                        vm.toggleLocked(app.pkg)
                                    } else {
                                        Toast.makeText(ctx, "O PIN precisa ter ao menos 4 números", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else {
                                vm.toggleLocked(app.pkg)
                            }
                        })
                    }
                    add("Ocultar" to { vm.toggleHidden(app.pkg); vm.menuApp = null })
                    add("Informações do app" to {
                        vm.menuApp = null
                        runCatching {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    })
                    add("Desinstalar" to {
                        vm.menuApp = null
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    })
                }
                LazyColumn(Modifier.heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows.size) { i -> MenuRow(rows[i].first, onClick = rows[i].second) }
                }
            }
        }
    }

    // ---- Lista de opções genérica ----
    vm.choice?.let { c: ChoiceRequest ->
        Dialog(onDismissRequest = { vm.choice = null }) {
            PanelCard(c.title) {
                LazyColumn(Modifier.heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(c.options.size) { i ->
                        val (value, label) = c.options[i]
                        MenuRow(label, if (c.fontPreview) fontFamilyFor(value) else null) {
                            vm.choice = null
                            c.onPick(value)
                        }
                    }
                }
            }
        }
    }

    // ---- Escolher pasta ----
    vm.folderPickApp?.let { app ->
        Dialog(onDismissRequest = { vm.folderPickApp = null }) {
            PanelCard("Mover ${vm.labelOf(app)} para…") {
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(p.folders.size) { i ->
                        MenuRow(p.folders[i].name) { vm.addToFolder(i, app.pkg); vm.folderPickApp = null }
                    }
                    item {
                        MenuRow("+ Nova pasta") {
                            vm.folderPickApp = null
                            vm.prompt = TextPrompt("Nome da pasta") { name ->
                                if (name.isNotBlank()) vm.addFolder(name.trim(), app.pkg)
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- Pasta aberta ----
    vm.openFolder?.let { idx ->
        val folder = p.folders.getOrNull(idx)
        if (folder == null) {
            vm.openFolder = null
        } else {
            Dialog(onDismissRequest = { vm.openFolder = null }) {
                PanelCard(folder.name, width = 760.dp) {
                    val apps = folder.pkgs.mapNotNull { vm.appByPkg(it) }
                    if (apps.isEmpty()) {
                        Text("Pasta vazia. Segure um app e use \"Mover para pasta…\".", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.height(260.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(apps, key = { it.pkg }) { a -> AppTile(vm, a) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            vm.prompt = TextPrompt("Renomear pasta", folder.name) { vm.renameFolder(idx, it) }
                        }) { Text("Renomear") }
                        TextButton(onClick = {
                            vm.appPicker = { a -> vm.addToFolder(idx, a.pkg) }
                        }) { Text("Adicionar app") }
                        if (apps.isNotEmpty()) {
                            TextButton(onClick = {
                                vm.appPicker = { a -> vm.removeFromFolder(idx, a.pkg) }
                            }) { Text("Remover app") }
                        }
                        TextButton(onClick = { vm.deleteFolder(idx); vm.openFolder = null }) { Text("Excluir pasta") }
                    }
                }
            }
        }
    }

    // ---- Seletor de app ----
    vm.appPicker?.let { onPick ->
        Dialog(onDismissRequest = { vm.appPicker = null }) {
            PanelCard("Escolha um app") {
                LazyColumn(Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.allApps, key = { it.pkg }) { a ->
                        MenuRow(vm.labelOf(a)) { vm.appPicker = null; onPick(a) }
                    }
                }
            }
        }
    }

    // ---- Gerenciar apps ocultos ----
    if (vm.hiddenManager) {
        Dialog(onDismissRequest = { vm.hiddenManager = false }) {
            PanelCard("Apps ocultos") {
                LazyColumn(Modifier.height(380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.allApps, key = { it.pkg }) { a ->
                        val hidden = a.pkg in p.hidden
                        MenuRow((if (hidden) "🙈  " else "👁  ") + vm.labelOf(a)) { vm.toggleHidden(a.pkg) }
                    }
                }
            }
        }
    }

    // ---- Prompt de texto ----
    vm.prompt?.let { pr ->
        var text by remember(pr) { mutableStateOf(pr.initial) }
        AlertDialog(
            onDismissRequest = { vm.prompt = null },
            title = { Text(pr.title) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = if (pr.numeric) KeyboardType.NumberPassword else KeyboardType.Text)
                )
            },
            confirmButton = { TextButton(onClick = { vm.prompt = null; pr.onOk(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { vm.prompt = null }) { Text("Cancelar") } }
        )
    }

    // ---- PIN ----
    vm.pinRequest?.let { req ->
        PinDialog(req, onDismiss = { vm.pinRequest = null }) { vm.pinRequest = null }
    }

    // ---- Painéis ----
    if (vm.weatherPanel) WeatherPanel(vm)
    if (vm.notifPanel) NotifPanel(vm)
    if (vm.btPanel) BluetoothPanel(vm, actions)
}

@Composable
private fun PinDialog(req: PinRequest, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var pin by remember(req) { mutableStateOf("") }
    var error by remember(req) { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        PanelCard(req.title, width = 420.dp) {
            Text(
                "•".repeat(pin.length).ifEmpty { " " },
                fontSize = 30.sp,
                color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(10.dp))
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK")
            keys.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { k ->
                        FocusBox(
                            Modifier.weight(1f),
                            RoundedCornerShape(12.dp),
                            1.05f,
                            style = panelStyle(),
                            onClick = {
                                error = false
                                when (k) {
                                    "⌫" -> pin = pin.dropLast(1)
                                    "OK" -> if (pin == req.expected) {
                                        onSuccess()
                                        req.onOk()
                                    } else {
                                        error = true
                                        pin = ""
                                    }
                                    else -> if (pin.length < 8) pin += k
                                }
                            }
                        ) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                Text(k, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }
    }
}
