package com.aura.launcher

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.tv.TvInputManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { HOME, SETTINGS }

class TextPrompt(
    val title: String,
    val initial: String = "",
    val numeric: Boolean = false,
    val onOk: (String) -> Unit
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var profiles by mutableStateOf(store.load())
        private set
    var current by mutableIntStateOf(store.current)
        private set

    val profile: Profile get() = profiles[current]

    var allApps by mutableStateOf<List<AppItem>>(emptyList())
        private set
    var inputs by mutableStateOf<List<InputItem>>(emptyList())
        private set

    val visibleApps: List<AppItem> get() = allApps.filter { it.pkg !in profile.hidden }

    var screen by mutableStateOf(Screen.HOME)

    // Cor extraída do papel de parede (cor dinâmica)
    var dynAccent by mutableStateOf<Int?>(null)

    // Estado dos diálogos
    var menuApp by mutableStateOf<AppItem?>(null)
    var openFolder by mutableStateOf<Int?>(null)
    var folderPickApp by mutableStateOf<AppItem?>(null)
    var pinTarget by mutableStateOf<Int?>(null)
    var prompt by mutableStateOf<TextPrompt?>(null)
    var appPicker by mutableStateOf<((AppItem) -> Unit)?>(null)
    var hiddenManager by mutableStateOf(false)
    var pendingIconPkg: String? = null

    init {
        reloadApps()
    }

    fun update(f: (Profile) -> Profile) {
        val list = profiles.toMutableList()
        list[current] = f(list[current])
        profiles = list
        store.save(list)
    }

    fun switchProfile(i: Int) {
        current = i
        store.current = i
        dynAccent = null
    }

    fun requestSwitch(i: Int) {
        if (i == current) return
        if (profiles[i].pin.isNotEmpty()) pinTarget = i else switchProfile(i)
    }

    fun labelOf(app: AppItem): String = profile.customNames[app.pkg] ?: app.label

    fun appByPkg(pkg: String): AppItem? = allApps.firstOrNull { it.pkg == pkg }

    fun goHome() {
        screen = Screen.HOME
        menuApp = null
        openFolder = null
        folderPickApp = null
        prompt = null
        appPicker = null
        hiddenManager = false
    }

    fun reloadApps() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val (apps, ins) = withContext(Dispatchers.IO) { Pair(queryApps(ctx), queryInputs(ctx)) }
            allApps = apps
            inputs = ins
        }
    }

    private fun queryApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName == ctx.packageName || found.containsKey(ai.packageName)) continue
                val intent = Intent(Intent.ACTION_MAIN)
                    .addCategory(cat)
                    .setClassName(ai.packageName, ai.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                found[ai.packageName] = AppItem(ai.packageName, ri.loadLabel(pm).toString(), intent)
            }
        }
        return found.values.sortedBy { it.label.lowercase() }
    }

    private fun queryInputs(ctx: Context): List<InputItem> = runCatching {
        val tm = ctx.getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        tm.tvInputList.filter { it.isPassthroughInput }
            .map { InputItem(it.id, it.loadLabel(ctx)?.toString() ?: it.id) }
    }.getOrDefault(emptyList())

    // ---- Favoritos / pastas / ocultos ----
    fun toggleFavorite(pkg: String) = update {
        if (pkg in it.favorites) it.copy(favorites = it.favorites - pkg)
        else it.copy(favorites = it.favorites + pkg)
    }

    fun toggleHidden(pkg: String) = update {
        if (pkg in it.hidden) it.copy(hidden = it.hidden - pkg)
        else it.copy(hidden = it.hidden + pkg, favorites = it.favorites - pkg)
    }

    fun addFolder(name: String, pkg: String? = null) = update {
        it.copy(folders = it.folders + Folder(name, listOfNotNull(pkg)))
    }

    fun addToFolder(index: Int, pkg: String) = update { p ->
        p.copy(folders = p.folders.mapIndexed { i, f ->
            if (i == index && pkg !in f.pkgs) f.copy(pkgs = f.pkgs + pkg) else f
        })
    }

    fun removeFromFolder(index: Int, pkg: String) = update { p ->
        p.copy(folders = p.folders.mapIndexed { i, f ->
            if (i == index) f.copy(pkgs = f.pkgs - pkg) else f
        })
    }

    fun renameFolder(index: Int, name: String) = update { p ->
        p.copy(folders = p.folders.mapIndexed { i, f -> if (i == index) f.copy(name = name) else f })
    }

    fun deleteFolder(index: Int) = update { p ->
        p.copy(folders = p.folders.filterIndexed { i, _ -> i != index })
    }

    fun renameApp(pkg: String, name: String) = update {
        if (name.isBlank()) it.copy(customNames = it.customNames - pkg)
        else it.copy(customNames = it.customNames + (pkg to name.trim()))
    }

    fun setCustomIcon(pkg: String, uri: String?) = update {
        if (uri == null) it.copy(customIcons = it.customIcons - pkg)
        else it.copy(customIcons = it.customIcons + (pkg to uri))
    }

    // ---- Backup ----
    fun exportJson(): String = store.exportJson(profiles)

    fun importJson(text: String): Boolean {
        val list = store.parseBackup(text) ?: return false
        profiles = list
        store.save(list)
        dynAccent = null
        return true
    }

    fun hasPm(): PackageManager = getApplication<Application>().packageManager
}
