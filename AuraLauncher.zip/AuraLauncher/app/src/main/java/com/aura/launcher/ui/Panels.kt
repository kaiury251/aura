package com.aura.launcher.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.aura.launcher.Actions
import com.aura.launcher.HomeViewModel
import com.aura.launcher.NotifHub
import com.aura.launcher.notifAccessEnabled
import com.aura.launcher.openNotifAccess
import com.aura.launcher.weatherEmoji
import com.aura.launcher.weatherText
import java.text.DateFormat
import java.util.Date

// ---------------------------------------------------------------------------------------------
// Clima detalhado
// ---------------------------------------------------------------------------------------------

@Composable
fun WeatherPanel(vm: HomeViewModel) {
    val w = vm.weather
    Dialog(onDismissRequest = { vm.weatherPanel = false }) {
        PanelCard("Clima — ${vm.profile.city}", width = 660.dp) {
            if (w == null) {
                Text("Carregando previsão…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(weatherEmoji(w.code), fontSize = 54.sp)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("${w.temp}°C", fontSize = 40.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text(weatherText(w.code), fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Sensação ${w.feels}°C", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("Umidade ${w.humidity}%", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("Vento ${w.wind} km/h", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f))
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    w.days.forEach { d ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(weatherEmoji(d.code), fontSize = 26.sp)
                            Text("${d.max}°", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("${d.min}°", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("💧${d.rain}%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Central de notificações
// ---------------------------------------------------------------------------------------------

@Composable
fun NotifPanel(vm: HomeViewModel) {
    val ctx = LocalContext.current
    val enabled = notifAccessEnabled(ctx)
    Dialog(onDismissRequest = { vm.notifPanel = false }) {
        PanelCard("Notificações", width = 640.dp) {
            if (!enabled) {
                Text(
                    "Para ver as notificações do sistema aqui, libere o acesso a notificações para o Aura Launcher.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                MenuRow("Liberar acesso a notificações") { openNotifAccess(ctx) }
            } else if (NotifHub.items.isEmpty()) {
                Text("Nenhuma notificação.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(NotifHub.items.toList(), key = { it.key }) { n ->
                        FocusBox(
                            Modifier.fillMaxWidth(),
                            androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                            1.02f,
                            style = panelStyle(),
                            onClick = {
                                runCatching { n.intent?.send() }
                                vm.notifPanel = false
                            },
                            onLongClick = { NotifHub.service?.cancelNotification(n.key) }
                        ) {
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Text(n.app, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                Text(
                                    n.title.ifBlank { "(sem título)" },
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (n.text.isNotBlank()) {
                                    Text(
                                        n.text,
                                        fontSize = 13.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(n.time)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "OK abre a notificação. Segure OK para dispensar.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                MenuRow("Limpar todas") { NotifHub.service?.cancelAllNotifications() }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Bluetooth
// ---------------------------------------------------------------------------------------------

fun btPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

fun btPermitted(ctx: Context): Boolean = btPermissions().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

@SuppressLint("MissingPermission")
private fun devName(d: BluetoothDevice): String =
    runCatching { d.name }.getOrNull()?.takeIf { it.isNotBlank() } ?: d.address

@SuppressLint("MissingPermission")
@Composable
fun BluetoothPanel(vm: HomeViewModel, actions: Actions) {
    val ctx = LocalContext.current
    val adapter: BluetoothAdapter? = remember {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    val permitted = remember(vm.btTick) { btPermitted(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    var paired by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var found by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }

    LaunchedEffect(tick, permitted) {
        paired = if (permitted) {
            runCatching { adapter?.bondedDevices?.toList() }.getOrNull().orEmpty()
        } else emptyList()
    }

    DisposableEffect(adapter) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val intent = i ?: return
                when (intent.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        if (d != null && found.none { it.address == d.address } &&
                            runCatching { d.bondState }.getOrDefault(0) != BluetoothDevice.BOND_BONDED
                        ) {
                            found = found + d
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanning = false
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> tick++
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose {
            runCatching { ctx.unregisterReceiver(receiver) }
            runCatching { adapter?.cancelDiscovery() }
        }
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun openBtSettings() {
        try {
            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Esta TV não tem a tela de Bluetooth")
        }
    }

    Dialog(onDismissRequest = { vm.btPanel = false }) {
        PanelCard("Bluetooth", width = 600.dp) {
            when {
                adapter == null -> {
                    Text("Este aparelho não tem Bluetooth.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                !permitted -> {
                    Text(
                        "Permita o acesso ao Bluetooth para listar e parear dispositivos.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    MenuRow("Permitir Bluetooth") { actions.askBt() }
                }
                !adapter.isEnabled -> {
                    Text("O Bluetooth está desligado.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    MenuRow("Ligar Bluetooth") {
                        try {
                            ctx.startActivity(
                                Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {
                            openBtSettings()
                        }
                    }
                }
                else -> {
                    LazyColumn(Modifier.heightIn(max = 340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            Text("Pareados", fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        if (paired.isEmpty()) {
                            item { Text("Nenhum dispositivo pareado.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        items(paired, key = { "p-" + it.address }) { d ->
                            MenuRow("${devName(d)}   (OK = remover pareamento)") {
                                val ok = runCatching { d.javaClass.getMethod("removeBond").invoke(d) }.isSuccess
                                if (ok) tick++ else {
                                    toast("Não foi possível remover aqui. Abrindo os ajustes do Bluetooth.")
                                    openBtSettings()
                                }
                            }
                        }
                        item {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (scanning) "Procurando…" else "Dispositivos encontrados",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        items(found, key = { "f-" + it.address }) { d ->
                            MenuRow("${devName(d)}   (OK = parear)") {
                                val started = runCatching { d.createBond() }.getOrDefault(false)
                                if (!started) toast("Não foi possível iniciar o pareamento")
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    MenuRow(if (scanning) "Parar busca" else "Procurar dispositivos") {
                        if (scanning) {
                            runCatching { adapter.cancelDiscovery() }
                            scanning = false
                        } else {
                            found = emptyList()
                            scanning = runCatching { adapter.startDiscovery() }.getOrDefault(false)
                            if (!scanning) toast("Não foi possível iniciar a busca")
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            MenuRow("Abrir ajustes do Bluetooth do sistema") { openBtSettings() }
        }
    }
}
