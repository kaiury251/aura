package com.aura.launcher.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Xml
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.util.concurrent.ConcurrentHashMap

object IconCache {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()

    suspend fun get(
        ctx: Context,
        pkg: String,
        customUri: String?,
        pack: String,
        banner: Boolean
    ): ImageBitmap? = withContext(Dispatchers.IO) {
        val key = "$pkg|${customUri.orEmpty()}|$pack|$banner"
        cache[key]?.let { return@withContext it }
        val bmp: Bitmap? = runCatching {
            when {
                !customUri.isNullOrBlank() -> decodeUri(ctx, customUri)
                pack.isNotBlank() -> IconPacks.icon(ctx, pack, pkg) ?: loadSystem(ctx, pkg, banner)
                else -> loadSystem(ctx, pkg, banner)
            }
        }.getOrNull()
        bmp?.asImageBitmap()?.also { cache[key] = it }
    }

    fun clearAll() {
        cache.clear()
    }

    private fun loadSystem(ctx: Context, pkg: String, banner: Boolean): Bitmap? {
        val pm = ctx.packageManager
        val d = (if (banner) pm.getApplicationBanner(pkg) else null) ?: pm.getApplicationIcon(pkg)
        val w = d.intrinsicWidth.takeIf { it > 0 } ?: 256
        val h = d.intrinsicHeight.takeIf { it > 0 } ?: 256
        val scale = minOf(1f, 640f / maxOf(w, h))
        return d.toBitmap((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
    }

    private fun decodeUri(ctx: Context, uri: String): Bitmap? {
        val u = Uri.parse(uri)
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / sample > 1280) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
}

/** Suporte a pacotes de ícones externos no formato appfilter.xml (ADW/Nova/Apex). */
object IconPacks {
    private val actions = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "com.gau.go.launcherex.theme"
    )
    private val maps = ConcurrentHashMap<String, Map<String, String>>()

    /** Lista de pares (pacote, nome) dos pacotes de ícones instalados. */
    fun installed(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val res = LinkedHashMap<String, String>()
        for (a in actions) {
            runCatching {
                pm.queryIntentActivities(Intent(a), 0).forEach { ri ->
                    val p = ri.activityInfo.packageName
                    if (!res.containsKey(p)) res[p] = ri.loadLabel(pm).toString()
                }
            }
        }
        return res.map { it.key to it.value }.sortedBy { it.second.lowercase() }
    }

    private fun mapping(ctx: Context, pack: String): Map<String, String> =
        maps.getOrPut(pack) { runCatching { parse(ctx, pack) }.getOrDefault(emptyMap()) }

    private fun parse(ctx: Context, pack: String): Map<String, String> {
        val res = ctx.packageManager.getResourcesForApplication(pack)
        val id = res.getIdentifier("appfilter", "xml", pack)
        val parser: XmlPullParser = if (id != 0) {
            res.getXml(id)
        } else {
            val p = Xml.newPullParser()
            p.setInput(res.assets.open("appfilter.xml"), null)
            p
        }
        val out = HashMap<String, String>()
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val dr = parser.getAttributeValue(null, "drawable")
                if (comp != null && dr != null && comp.startsWith("ComponentInfo{")) {
                    val pkg = comp.removePrefix("ComponentInfo{").substringBefore('/')
                    if (!out.containsKey(pkg)) out[pkg] = dr
                }
            }
            ev = parser.next()
        }
        return out
    }

    fun icon(ctx: Context, pack: String, pkg: String): Bitmap? {
        val name = mapping(ctx, pack)[pkg] ?: return null
        val res = ctx.packageManager.getResourcesForApplication(pack)
        val id = res.getIdentifier(name, "drawable", pack)
        if (id == 0) return null
        val d = ResourcesCompat.getDrawable(res, id, null) ?: return null
        return d.toBitmap(256, 256)
    }
}
