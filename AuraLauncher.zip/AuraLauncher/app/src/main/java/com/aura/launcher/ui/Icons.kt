package com.aura.launcher.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

object IconCache {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()

    suspend fun get(ctx: Context, pkg: String, customUri: String?): ImageBitmap? =
        withContext(Dispatchers.IO) {
            val key = if (customUri.isNullOrBlank()) pkg else "$pkg|$customUri"
            cache[key]?.let { return@withContext it }
            val bmp: Bitmap? = runCatching {
                if (!customUri.isNullOrBlank()) decodeUri(ctx, customUri)
                else loadSystem(ctx, pkg)
            }.getOrNull()
            bmp?.asImageBitmap()?.also { cache[key] = it }
        }

    fun clearCustom() {
        cache.keys.filter { it.contains("|") }.forEach { cache.remove(it) }
    }

    private fun loadSystem(ctx: Context, pkg: String): Bitmap? {
        val pm = ctx.packageManager
        val d = pm.getApplicationBanner(pkg) ?: pm.getApplicationIcon(pkg)
        val w = d.intrinsicWidth.takeIf { it > 0 } ?: 256
        val h = d.intrinsicHeight.takeIf { it > 0 } ?: 256
        val scale = minOf(1f, 640f / maxOf(w, h))
        return d.toBitmap((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
    }

    private fun decodeUri(ctx: Context, uri: String): Bitmap? {
        val u = Uri.parse(uri)
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / sample > 1280) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
}
