package com.aura.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val PROFILE_COUNT = 4

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val raw = sp.getString("profiles", null)
        val list = mutableListOf<Profile>()
        if (raw != null) {
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) list.add(profileFromJson(arr.getJSONObject(i)))
            }
        }
        while (list.size < PROFILE_COUNT) list.add(Profile(name = "Perfil ${list.size + 1}"))
        return list.take(PROFILE_COUNT)
    }

    fun save(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString("profiles", arr.toString()).apply()
    }

    var current: Int
        get() = sp.getInt("current", 0).coerceIn(0, PROFILE_COUNT - 1)
        set(v) = sp.edit().putInt("current", v).apply()

    fun exportJson(list: List<Profile>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return JSONObject().put("app", "aura").put("version", 1).put("profiles", arr).toString(2)
    }

    fun parseBackup(text: String): List<Profile>? = runCatching {
        val arr = JSONObject(text).getJSONArray("profiles")
        val list = (0 until arr.length()).map { profileFromJson(arr.getJSONObject(it)) }.toMutableList()
        while (list.size < PROFILE_COUNT) list.add(Profile(name = "Perfil ${list.size + 1}"))
        list.take(PROFILE_COUNT)
    }.getOrNull()
}
