package com.aura.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.aura.launcher.ui.AuraTheme
import com.aura.launcher.ui.Dialogs
import com.aura.launcher.ui.HomeScreen
import com.aura.launcher.ui.IconCache
import com.aura.launcher.ui.SettingsScreen
import com.aura.launcher.ui.Wallpaper
import com.aura.launcher.ui.launchApp

class Actions(
    val pickWallpaper: () -> Unit,
    val pickIcon: (String) -> Unit,
    val exportBackup: () -> Unit,
    val importBackup: () -> Unit
)

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels()

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            vm.reloadApps()
        }
    }

    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            persist(uri)
            val mime = contentResolver.getType(uri) ?: ""
            vm.update { it.copy(wallUri = uri.toString(), wallType = if (mime.startsWith("video")) "video" else "image") }
        }
    }

    private val iconPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val pkg = vm.pendingIconPkg
        if (uri != null && pkg != null) {
            persist(uri)
            IconCache.clearCustom()
            vm.setCustomIcon(pkg, uri.toString())
        }
    }

    private val exportPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray()) }
                toast("Backup salvo")
            }.onFailure { toast("Erro ao salvar o backup") }
        }
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text != null && vm.importJson(text)) {
                IconCache.clearCustom()
                toast("Configurações restauradas")
            } else toast("Arquivo de backup inválido")
        }
    }

    private val actions = Actions(
        pickWallpaper = { safely { wallpaperPicker.launch(arrayOf("image/*", "video/*")) } },
        pickIcon = { pkg ->
            vm.pendingIconPkg = pkg
            safely { iconPicker.launch(arrayOf("image/*")) }
        },
        exportBackup = { safely { exportPicker.launch("aura-backup.json") } },
        importBackup = { safely { importPicker.launch(arrayOf("application/json", "text/plain", "*/*")) } }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        setContent { AuraApp(vm, actions) }

        // App de início automático: só na primeira vez que o processo sobe
        if (savedInstanceState == null && !autostartDone) {
            autostartDone = true
            val pkg = vm.profile.autostart
            if (pkg.isNotEmpty()) {
                window.decorView.postDelayed({
                    vm.appByPkg(pkg)?.let { launchApp(this, it, "fade") }
                }, 1500)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Botão Home pressionado: volta para a tela inicial
        vm.goHome()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(packageReceiver) }
        super.onDestroy()
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun safely(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            toast("Este aparelho não tem seletor de arquivos. Use o endereço (URL) como alternativa.")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private var autostartDone = false
    }
}

@Composable
fun AuraApp(vm: HomeViewModel, actions: Actions) {
    val p = vm.profile
    val accent = if (p.dynamic && vm.dynAccent != null) Color(vm.dynAccent!!) else Color(p.accent)
    AuraTheme(accent) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
            Wallpaper(vm)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = p.dim)))
            when (vm.screen) {
                Screen.HOME -> HomeScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm, actions)
            }
            Dialogs(vm, actions)
        }
    }
}
