package com.aura.launcher.ui

import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aura.launcher.HomeViewModel
import com.aura.launcher.Net
import kotlinx.coroutines.delay

@Composable
fun Wallpaper(vm: HomeViewModel) {
    val p = vm.profile
    val ctx = LocalContext.current
    val accent = Color(p.accent)

    when {
        p.wallType == "image" && p.wallUri.isNotBlank() -> {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(p.wallUri).allowHardware(false).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                onSuccess = { st ->
                    val bmp = (st.result.drawable as? BitmapDrawable)?.bitmap
                    if (bmp != null && p.dynamic) {
                        Palette.from(bmp).maximumColorCount(16).generate { pal ->
                            val sw = pal?.vibrantSwatch ?: pal?.dominantSwatch
                            if (sw != null) vm.dynAccent = sw.rgb or (0xFF shl 24)
                        }
                    }
                }
            )
        }

        p.wallType == "video" && p.wallUri.isNotBlank() -> {
            val player = remember(p.wallUri) {
                ExoPlayer.Builder(ctx).build().apply {
                    setMediaItem(MediaItem.fromUri(Uri.parse(p.wallUri)))
                    repeatMode = Player.REPEAT_MODE_ALL
                    volume = 0f
                    playWhenReady = true
                    prepare()
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = {
                    PlayerView(it).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        this.player = player
                    }
                },
                update = { it.player = player }
            )
        }

        p.wallType == "poster" && p.tmdbKey.isNotBlank() -> {
            var urls by remember(p.tmdbKey) { mutableStateOf<List<String>>(emptyList()) }
            var idx by remember(p.tmdbKey) { mutableStateOf(0) }
            LaunchedEffect(p.tmdbKey) { urls = Net.posters(p.tmdbKey).shuffled() }
            LaunchedEffect(urls) {
                while (urls.size > 1) {
                    delay(12_000)
                    idx = (idx + 1) % urls.size
                }
            }
            if (urls.isEmpty()) {
                GradientBg(accent)
            } else {
                Crossfade(targetState = urls[idx % urls.size], animationSpec = tween(1500), label = "poster") { u ->
                    AsyncImage(
                        model = u,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        else -> {
            val c = if (p.dynamic && vm.dynAccent != null) Color(vm.dynAccent!!) else accent
            GradientBg(c)
        }
    }
}

@Composable
private fun GradientBg(c: Color) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(lerp(Color.Black, c, 0.55f), lerp(Color.Black, c, 0.15f))
                )
            )
    )
}
