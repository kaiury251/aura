package com.aura.launcher.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.launcher.Net
import com.aura.launcher.weatherEmoji
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ClockWidget() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(10_000)
        }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEE, d 'de' MMM", Locale.getDefault()).format(now)
    Column {
        Text(time, fontSize = 44.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onSurface)
        Text(date, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun WeatherWidget(lat: Double, lon: Double, city: String) {
    var data by remember(lat, lon) { mutableStateOf<Pair<Int, Int>?>(null) }
    LaunchedEffect(lat, lon) {
        while (true) {
            Net.weather(lat, lon)?.let { data = it }
            delay(30 * 60_000L)
        }
    }
    Row {
        Text(data?.let { weatherEmoji(it.second) } ?: "🌡️", fontSize = 34.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                data?.let { "${it.first}°C" } ?: "--",
                fontSize = 26.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(city, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun RssWidget(url: String) {
    var titles by remember(url) { mutableStateOf<List<String>>(emptyList()) }
    var idx by remember(url) { mutableStateOf(0) }
    LaunchedEffect(url) {
        while (true) {
            val t = Net.rss(url)
            if (t.isNotEmpty()) titles = t
            delay(20 * 60_000L)
        }
    }
    LaunchedEffect(titles) {
        while (titles.size > 1) {
            delay(8_000)
            idx = (idx + 1) % titles.size
        }
    }
    Column {
        Text("Notícias", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
        Crossfade(
            targetState = titles.getOrNull(idx) ?: if (url.isBlank()) "Defina um feed RSS nos ajustes" else "Carregando…",
            label = "rss"
        ) {
            Text(
                it,
                fontSize = 18.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
