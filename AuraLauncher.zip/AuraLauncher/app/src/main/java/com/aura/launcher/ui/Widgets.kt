package com.aura.launcher.ui

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.launcher.AuraNotifService
import com.aura.launcher.Net
import com.aura.launcher.WeatherData
import com.aura.launcher.weatherEmoji
import com.aura.launcher.weatherText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ClockWidget(showTime: Boolean, showDate: Boolean) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(10_000)
        }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEE, d 'de' MMM", Locale.getDefault()).format(now)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (showTime) {
            Text(
                time,
                fontSize = 44.sp,
                fontWeight = FontWeight.Light,
                color = MaterialTheme.colorScheme.onSurface,
                style = shadowed()
            )
        }
        if (showTime && showDate) Spacer(Modifier.width(16.dp))
        if (showDate) {
            Text(
                date,
                fontSize = if (showTime) 18.sp else 24.sp,
                color = MaterialTheme.colorScheme.onSurface,
                style = shadowed()
            )
        }
    }
}

@Composable
fun WeatherWidget(weather: WeatherData?, city: String, onClick: () -> Unit) {
    FocusBox(
        Modifier,
        RoundedCornerShape(14.dp),
        1.06f,
        style = "clear",
        onClick = onClick
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(weather?.let { weatherEmoji(it.code) } ?: "🌡️", fontSize = 34.sp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    weather?.let { "${it.temp}°C" } ?: "--",
                    fontSize = 26.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = shadowed()
                )
                Text(
                    city,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = shadowed()
                )
            }
        }
    }
}

private fun netLabel(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        ?: return "🌐 —"
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "📵 Sem rede"
    val base = when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "📶 Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "🔌 Ethernet"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "📱 Móvel"
        else -> "🌐 Online"
    }
    return if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) base else "$base (sem internet)"
}

@Composable
fun NetworkWidget() {
    val ctx = LocalContext.current
    var label by remember { mutableStateOf("🌐 …") }
    LaunchedEffect(Unit) {
        while (true) {
            label = runCatching { netLabel(ctx) }.getOrDefault("🌐 —")
            delay(5_000)
        }
    }
    Text(label, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface, style = shadowed())
}

private class NowPlaying(
    val controller: MediaController,
    val title: String,
    val artist: String,
    val playing: Boolean
)

private fun readMedia(ctx: Context): NowPlaying? {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val sessions = msm.getActiveSessions(ComponentName(ctx, AuraNotifService::class.java))
    val c = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        ?: sessions.firstOrNull()
        ?: return null
    val md = c.metadata ?: return null
    val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
    val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
    return NowPlaying(c, title, artist, c.playbackState?.state == PlaybackState.STATE_PLAYING)
}

/** "Tocando agora": precisa do acesso a notificações liberado nos ajustes do Android. */
@Composable
fun NowPlayingWidget() {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<NowPlaying?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            info = withContext(Dispatchers.Default) { runCatching { readMedia(ctx) }.getOrNull() }
            delay(2_000)
        }
    }
    val np = info ?: return
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.widthIn(max = 260.dp)) {
            Text(
                "♪ ${np.title}",
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface,
                style = shadowed()
            )
            if (np.artist.isNotEmpty()) {
                Text(
                    np.artist,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = shadowed()
                )
            }
        }
        MediaButton(Icons.Filled.SkipPrevious) { np.controller.transportControls.skipToPrevious() }
        MediaButton(if (np.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow) {
            if (np.playing) np.controller.transportControls.pause() else np.controller.transportControls.play()
        }
        MediaButton(Icons.Filled.SkipNext) { np.controller.transportControls.skipToNext() }
    }
}

@Composable
private fun MediaButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    FocusBox(Modifier, CircleShape, 1.15f, style = panelStyle(), onClick = onClick) {
        Icon(icon, null, Modifier.padding(6.dp), tint = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun RssWidget(url: String) {
    // TVs que não configuraram feed ainda usam um feed público em português.
    val effectiveUrl = url.trim().ifBlank { "https://feeds.bbci.co.uk/portuguese/rss.xml" }
    var titles by remember(effectiveUrl) { mutableStateOf<List<String>>(emptyList()) }
    var idx by remember(effectiveUrl) { mutableStateOf(0) }
    LaunchedEffect(effectiveUrl) {
        while (true) {
            val t = Net.rss(effectiveUrl)
            if (t.isNotEmpty()) titles = t
            delay(20 * 60_000L)
        }
    }
    LaunchedEffect(titles) {
        while (titles.size > 1) {
            delay(8_000)
            idx = (idx + 1) % titles.size
        }
    }
    Column {
        Text("Notícias", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, style = shadowed())
        Crossfade(
            targetState = titles.getOrNull(idx) ?: if (url.isBlank()) "Carregando notícias (BBC Brasil)…" else "Carregando…",
            label = "rss"
        ) {
            Text(
                it,
                fontSize = 18.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface,
                style = shadowed()
            )
        }
    }
}
