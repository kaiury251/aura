package com.aura.launcher.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.launcher.Actions
import com.aura.launcher.HomeViewModel
import com.aura.launcher.Net
import com.aura.launcher.Screen
import com.aura.launcher.TextPrompt
import kotlinx.coroutines.launch

private val ACCENTS = listOf(
    0xFF7C5CFF, 0xFF4F8BFF, 0xFF00B8A9, 0xFF3DDC84,
    0xFFFFB300, 0xFFFF6D3A, 0xFFFF4D6D, 0xFFE040FB
).map { it.toInt() }

private fun <T> cycle(list: List<T>, cur: T): T = list[(list.indexOf(cur) + 1).mod(list.size)]

@Composable
fun SettingsScreen(vm: HomeViewModel, actions: Actions) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = vm.profile
    BackHandler { vm.screen = Screen.HOME }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 120.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("Ajustes — ${p.name}", fontSize = 28.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        }

        item { Header("Perfil") }
        item {
            Row2("Nome do perfil", p.name) {
                vm.prompt = TextPrompt("Nome do perfil", p.name) { n -> if (n.isNotBlank()) vm.update { it.copy(name = n.trim()) } }
            }
        }
        item {
            Row2("PIN do perfil", if (p.pin.isEmpty()) "Sem PIN" else "Ativo (••••)") {
                vm.prompt = TextPrompt("Defina o PIN (vazio remove)", "", numeric = true) { pin ->
                    vm.update { it.copy(pin = pin.filter(Char::isDigit)) }
                }
            }
        }

        item { Header("Papel de parede") }
        item {
            val label = mapOf("color" to "Cor / degradê", "image" to "Imagem", "video" to "Vídeo", "poster" to "Posters de filmes (TMDB)")
            Row2("Tipo", label[p.wallType] ?: p.wallType) {
                vm.update { it.copy(wallType = cycle(listOf("color", "image", "video", "poster"), it.wallType)) }
            }
        }
        item { Row2("Escolher imagem ou vídeo do aparelho", "Abre o seletor de arquivos") { actions.pickWallpaper() } }
        item {
            Row2("Endereço (URL) de imagem ou vídeo", p.wallUri.ifBlank { "Nenhum" }) {
                vm.prompt = TextPrompt("URL do papel de parede", p.wallUri) { u ->
                    val url = u.trim()
                    val isVideo = listOf(".mp4", ".webm", ".m3u8", ".mkv").any { url.lowercase().contains(it) }
                    vm.update { it.copy(wallUri = url, wallType = if (isVideo) "video" else "image") }
                }
            }
        }
        item {
            Row2("Chave da API do TMDB (posters)", if (p.tmdbKey.isBlank()) "Não definida — chave gratuita em themoviedb.org" else "Definida") {
                vm.prompt = TextPrompt("Chave da API do TMDB", p.tmdbKey) { k ->
                    vm.update { it.copy(tmdbKey = k.trim(), wallType = if (k.isNotBlank()) "poster" else it.wallType) }
                }
            }
        }
        item {
            Row2("Escurecer fundo", "${(p.dim * 100).toInt()}%") {
                val steps = listOf(0f, 0.15f, 0.3f, 0.45f, 0.6f, 0.75f)
                val next = steps.firstOrNull { it > p.dim + 0.01f } ?: steps.first()
                vm.update { it.copy(dim = next) }
            }
        }

        item { Header("Cores") }
        item {
            Toggle("Cores dinâmicas (seguem o papel de parede)", p.dynamic) {
                vm.update { it.copy(dynamic = !it.dynamic) }
                vm.dynAccent = null
            }
        }
        item {
            Column {
                Text("Cor de destaque", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ACCENTS.forEach { c ->
                        FocusBox(
                            Modifier.size(44.dp).background(Color(c), CircleShape),
                            CircleShape,
                            1.2f,
                            onClick = { vm.update { it.copy(accent = c, dynamic = false) } }
                        ) {
                            if (c == p.accent && !p.dynamic) {
                                Text("✓", Modifier.align(Alignment.Center), color = Color.White, fontSize = 20.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Row2("Cor em hexadecimal", "Ex.: #FF8800") {
                vm.prompt = TextPrompt("Cor (ex.: #FF8800)", "") { hex ->
                    val v = runCatching { android.graphics.Color.parseColor(if (hex.startsWith("#")) hex else "#$hex") }.getOrNull()
                    if (v != null) vm.update { it.copy(accent = v or (0xFF shl 24), dynamic = false) } else toast("Cor inválida")
                }
            }
        }

        item { Header("Animações") }
        item {
            val names = mapOf("none" to "Nenhuma", "fade" to "Desvanecer", "zoom" to "Zoom", "slide" to "Deslizar")
            Row2("Animação ao abrir app", names[p.anim] ?: p.anim) {
                vm.update { it.copy(anim = cycle(listOf("none", "fade", "zoom", "slide"), it.anim)) }
            }
        }
        item {
            Row2("Tamanho do foco", "${(p.focusScale * 100).toInt()}%") {
                val steps = listOf(1.0f, 1.06f, 1.12f, 1.2f)
                val next = steps.firstOrNull { it > p.focusScale + 0.005f } ?: steps.first()
                vm.update { it.copy(focusScale = next) }
            }
        }
        item {
            Row2("Esconder itens quando ocioso", if (p.idleFade == 0) "Desligado" else "${p.idleFade} s") {
                vm.update { it.copy(idleFade = cycle(listOf(0, 15, 30, 60, 120), it.idleFade)) }
            }
        }

        item { Header("Widgets") }
        item { Toggle("Relógio", p.showClock) { vm.update { it.copy(showClock = !it.showClock) } } }
        item { Toggle("Clima", p.showWeather) { vm.update { it.copy(showWeather = !it.showWeather) } } }
        item {
            Row2("Cidade do clima", p.city) {
                vm.prompt = TextPrompt("Nome da cidade", p.city) { name ->
                    scope.launch {
                        val r = Net.geocode(name)
                        if (r != null) vm.update { it.copy(city = r.first, lat = r.second, lon = r.third, showWeather = true) }
                        else toast("Cidade não encontrada")
                    }
                }
            }
        }
        item { Toggle("Notícias (RSS/Atom)", p.showRss) { vm.update { it.copy(showRss = !it.showRss) } } }
        item {
            Row2("Endereço do feed RSS", p.rssUrl.ifBlank { "Nenhum" }) {
                vm.prompt = TextPrompt("URL do feed RSS ou Atom", p.rssUrl) { u ->
                    vm.update { it.copy(rssUrl = u.trim(), showRss = u.isNotBlank()) }
                }
            }
        }
        item { Toggle("Entradas HDMI / TV ao vivo", p.showInputs) { vm.update { it.copy(showInputs = !it.showInputs) } } }

        item { Header("Apps") }
        item { Row2("Apps ocultos", "${p.hidden.size} oculto(s)") { vm.hiddenManager = true } }
        item {
            val name = vm.appByPkg(p.autostart)?.label ?: "Nenhum"
            Row2("Abrir app ao iniciar o launcher", name) {
                vm.appPicker = { a -> vm.update { it.copy(autostart = a.pkg) } }
            }
        }
        item {
            if (p.autostart.isNotEmpty()) Row2("Remover app de início automático", "") { vm.update { it.copy(autostart = "") } }
        }

        item { Header("Backup") }
        item { Row2("Exportar configurações", "Salva todos os perfis em um arquivo .json") { actions.exportBackup() } }
        item { Row2("Importar configurações", "Restaura de um arquivo .json") { actions.importBackup() } }

        item { Header("Sistema") }
        item {
            Row2("Voltar à tela inicial", "") { vm.screen = Screen.HOME }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(
        text,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.padding(top = 16.dp, bottom = 2.dp)
    )
}

@Composable
private fun Row2(title: String, value: String, onClick: () -> Unit) {
    FocusBox(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant),
        RoundedCornerShape(12.dp),
        1.02f,
        onClick = onClick
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
            if (value.isNotEmpty()) {
                Text(value, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun Toggle(title: String, on: Boolean, onClick: () -> Unit) =
    Row2(title, if (on) "Ligado" else "Desligado", onClick)
