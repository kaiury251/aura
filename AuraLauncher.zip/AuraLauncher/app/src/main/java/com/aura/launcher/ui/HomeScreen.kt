package com.aura.launcher.ui

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.media.tv.TvContract
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.launcher.AppItem
import com.aura.launcher.HomeViewModel
import com.aura.launcher.R
import com.aura.launcher.Screen
import kotlinx.coroutines.delay

const val GRID_COLUMNS = 6

fun launchApp(ctx: Context, app: AppItem, anim: String) {
    val opts = when (anim) {
        "fade" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.fade_in, R.anim.fade_out)
        "zoom" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.zoom_in, R.anim.fade_out)
        "slide" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.slide_in, R.anim.fade_out)
        else -> null
    }
    try {
        ctx.startActivity(Intent(app.intent), opts?.toBundle())
    } catch (e: Exception) {
        Toast.makeText(ctx, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
    }
}

fun launchInput(ctx: Context, id: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(id))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Este aparelho não permite abrir a entrada por aqui", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val ctx = LocalContext.current
    val p = vm.profile

    var lastKey by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var idle by remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(p.idleFade, lastKey) {
        idle = false
        if (p.idleFade > 0) {
            delay(p.idleFade * 1000L)
            idle = true
        }
    }
    val alpha by animateFloatAsState(if (idle) 0f else 1f, tween(600), label = "idle")

    val visible = vm.visibleApps
    val favorites = p.favorites.mapNotNull { pk -> visible.firstOrNull { it.pkg == pk } }
    val rows = visible.chunked(GRID_COLUMNS)

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent {
                lastKey = System.currentTimeMillis()
                false
            }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .alpha(alpha),
            contentPadding = PaddingValues(horizontal = 48.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item { TopBar(vm) }

            if (p.showRss) {
                item { RssWidget(p.rssUrl) }
            }

            if (favorites.isNotEmpty()) {
                item {
                    Column {
                        SectionTitle("Favoritos")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(favorites, key = { it.pkg }) { app ->
                                AppTile(vm, app, Modifier.width(200.dp))
                            }
                        }
                    }
                }
            }

            if (p.showInputs && vm.inputs.isNotEmpty()) {
                item {
                  Column {
                    SectionTitle("Entradas")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                        items(vm.inputs, key = { it.id }) { input ->
                            FocusBox(
                                Modifier
                                    .width(200.dp)
                                    .aspectRatio(16f / 9f)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                RoundedCornerShape(14.dp),
                                p.focusScale,
                                onClick = { launchInput(ctx, input.id) }
                            ) {
                                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.Tv, null, tint = MaterialTheme.colorScheme.onSurface)
                                    Text(input.label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                  }
                }
            }

            if (p.folders.isNotEmpty()) {
                item {
                  Column {
                    SectionTitle("Pastas")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                        items(p.folders.size) { idx ->
                            val f = p.folders[idx]
                            FocusBox(
                                Modifier
                                    .width(200.dp)
                                    .aspectRatio(16f / 9f)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                RoundedCornerShape(14.dp),
                                p.focusScale,
                                onClick = { vm.openFolder = idx }
                            ) {
                                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.onSurface)
                                    Text(f.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${f.pkgs.size} apps", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                  }
                }
            }

            item { SectionTitle("Todos os apps") }
            items(rows.size) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    rows[r].forEach { app ->
                        AppTile(vm, app, Modifier.weight(1f))
                    }
                    repeat(GRID_COLUMNS - rows[r].size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
private fun TopBar(vm: HomeViewModel) {
    val p = vm.profile
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (p.showClock) ClockWidget()
        if (p.showWeather) {
            Spacer(Modifier.width(32.dp))
            WeatherWidget(p.lat, p.lon, p.city)
        }
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        vm.profiles.forEachIndexed { i, pr ->
            val selected = i == vm.current
            FocusBox(
                Modifier
                    .background(
                        if (selected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                RoundedCornerShape(50),
                1.1f,
                onClick = { vm.requestSwitch(i) }
            ) {
                Text(
                    pr.name + if (pr.pin.isNotEmpty()) " 🔒" else "",
                    fontSize = 13.sp,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        }
        Spacer(Modifier.width(8.dp))
        FocusBox(
            Modifier.background(MaterialTheme.colorScheme.surfaceVariant),
            RoundedCornerShape(50),
            1.15f,
            onClick = { vm.screen = Screen.SETTINGS }
        ) {
            Icon(Icons.Filled.Settings, "Ajustes", Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun AppTile(vm: HomeViewModel, app: AppItem, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val p = vm.profile
    val custom = p.customIcons[app.pkg]
    val bmp by produceState<ImageBitmap?>(null, app.pkg, custom) {
        value = IconCache.get(ctx, app.pkg, custom)
    }
    Column(modifier) {
        FocusBox(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            RoundedCornerShape(14.dp),
            p.focusScale,
            onClick = { launchApp(ctx, app, p.anim) },
            onLongClick = { vm.menuApp = app }
        ) {
            bmp?.let { b ->
                val wide = b.width.toFloat() / b.height > 1.5f
                if (wide) {
                    Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Image(b, null, Modifier.fillMaxSize().padding(10.dp), contentScale = ContentScale.Fit)
                }
            }
        }
        Text(
            vm.labelOf(app),
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(start = 4.dp, top = 4.dp)
        )
    }
}
