package com.aura.launcher.ui

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.media.tv.TvContract
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aura.launcher.AppItem
import com.aura.launcher.HomeViewModel
import com.aura.launcher.NotifHub
import com.aura.launcher.PinRequest
import com.aura.launcher.Profile
import com.aura.launcher.R
import com.aura.launcher.Screen
import kotlinx.coroutines.delay

fun launchApp(ctx: Context, app: AppItem, anim: String) {
    val opts = when (anim) {
        "fade" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.fade_in, R.anim.fade_out)
        "zoom" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.zoom_in, R.anim.fade_out)
        "slide" -> ActivityOptions.makeCustomAnimation(ctx, R.anim.slide_in, R.anim.fade_out)
        else -> null
    }
    try {
        ctx.startActivity(Intent(app.intent), opts?.toBundle())
    } catch (e: Exception) {
        Toast.makeText(ctx, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
    }
}

/** Abre o app respeitando o bloqueio por PIN. */
fun openApp(vm: HomeViewModel, ctx: Context, app: AppItem) {
    val p = vm.profile
    if (app.pkg in p.locked && p.appPin.isNotEmpty()) {
        vm.pinRequest = PinRequest("PIN para abrir ${vm.labelOf(app)}", p.appPin) {
            launchApp(ctx, app, p.anim)
        }
    } else {
        launchApp(ctx, app, p.anim)
    }
}

fun launchInput(ctx: Context, id: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(id))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Este aparelho não permite abrir a entrada por aqui", Toast.LENGTH_SHORT).show()
    }
}

private fun gridCols(p: Profile): Int {
    val i = p.iconSize.coerceIn(0, 2)
    return if (p.iconShape == "banner") listOf(8, 6, 5)[i] else listOf(12, 9, 7)[i]
}

private fun favWidth(p: Profile): Dp {
    val mul = listOf(0.8f, 1f, 1.25f)[p.iconSize.coerceIn(0, 2)]
    return (if (p.iconShape == "banner") 200.dp else 96.dp) * mul
}

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val ctx = LocalContext.current
    val p = vm.profile

    var lastKey by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var idle by remember { mutableStateOf(false) }
    LaunchedEffect(p.idleFade, lastKey) {
        idle = false
        if (p.idleFade > 0) {
            delay(p.idleFade * 1000L)
            idle = true
        }
    }
    val alpha by animateFloatAsState(if (idle) 0f else 1f, tween(600), label = "idle")

    val visible = vm.visibleApps
    val favorites = p.favorites.mapNotNull { pk -> visible.firstOrNull { it.pkg == pk } }
    val cols = gridCols(p)
    val rows = visible.chunked(cols)
    val tileStyle = p.tileStyle

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent {
                lastKey = System.currentTimeMillis()
                false
            }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .alpha(alpha),
            contentPadding = PaddingValues(horizontal = 48.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item { TopBar(vm) }

            if (p.showWeather || p.showNetwork || p.showNowPlaying || p.showRss) {
                item { InfoRow(vm) }
            }

            if (favorites.isNotEmpty()) {
                item {
                    Column {
                        SectionTitle("Favoritos")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(favorites, key = { it.pkg }) { app ->
                                AppTile(vm, app, Modifier.width(favWidth(p)))
                            }
                        }
                    }
                }
            }

            if (p.showInputs && vm.inputs.isNotEmpty()) {
                item {
                    Column {
                        SectionTitle("Entradas")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(vm.inputs, key = { it.id }) { input ->
                                FocusBox(
                                    Modifier
                                        .width(200.dp)
                                        .aspectRatio(16f / 9f),
                                    RoundedCornerShape(14.dp),
                                    p.focusScale,
                                    style = tileStyle,
                                    onClick = { launchInput(ctx, input.id) }
                                ) {
                                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.Tv, null, tint = MaterialTheme.colorScheme.onSurface)
                                        Text(input.label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (p.folders.isNotEmpty()) {
                item {
                    Column {
                        SectionTitle("Pastas")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(p.folders.size) { idx ->
                                val f = p.folders[idx]
                                FocusBox(
                                    Modifier
                                        .width(200.dp)
                                        .aspectRatio(16f / 9f),
                                    RoundedCornerShape(14.dp),
                                    p.focusScale,
                                    style = tileStyle,
                                    onClick = { vm.openFolder = idx }
                                ) {
                                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.onSurface)
                                        Text(f.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${f.pkgs.size} apps", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { SectionTitle("Todos os apps") }
            items(rows.size) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    rows[r].forEach { app ->
                        AppTile(vm, app, Modifier.weight(1f))
                    }
                    repeat(cols - rows[r].size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurface,
        style = shadowed(),
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
private fun InfoRow(vm: HomeViewModel) {
    val p = vm.profile
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (p.showWeather) WeatherWidget(vm.weather, p.city) { vm.weatherPanel = true }
        if (p.showNetwork) NetworkWidget()
        if (p.showNowPlaying) NowPlayingWidget()
        if (p.showRss) Box(Modifier.weight(1f)) { RssWidget(p.rssUrl) }
    }
}

@Composable
private fun TopBar(vm: HomeViewModel) {
    val p = vm.profile
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (p.showClock || p.showDate) ClockWidget(p.showClock, p.showDate)
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            vm.profiles.forEachIndexed { i, pr ->
                val selected = i == vm.current
                FocusBox(
                    Modifier,
                    RoundedCornerShape(50),
                    1.1f,
                    style = if (selected) "accent" else panelStyle(),
                    onClick = { vm.requestSwitch(i) }
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (pr.avatar.isNotBlank()) {
                            AsyncImage(
                                model = pr.avatar,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(
                            pr.name + if (pr.pin.isNotEmpty()) " 🔒" else "",
                            fontSize = 13.sp,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            if (p.showBell) {
                BarButton(Icons.Filled.Notifications, "Notificações", NotifHub.items.size) { vm.notifPanel = true }
            }
            if (p.showBluetooth) {
                BarButton(Icons.Filled.Bluetooth, "Bluetooth", 0) { vm.btPanel = true }
            }
            BarButton(Icons.Filled.Settings, "Ajustes", 0) { vm.screen = Screen.SETTINGS }
        }
    }
}

@Composable
private fun BarButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    badge: Int,
    onClick: () -> Unit
) {
    FocusBox(Modifier, CircleShape, 1.15f, style = panelStyle(), onClick = onClick) {
        Icon(icon, desc, Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.onSurface)
        if (badge > 0) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    if (badge > 9) "9+" else badge.toString(),
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

@Composable
fun AppTile(vm: HomeViewModel, app: AppItem, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val p = vm.profile

    val shapeKey = p.appShapes[app.pkg]?.takeIf { it.isNotBlank() } ?: p.iconShape
    val banner = shapeKey == "banner"
    val shape: Shape = when (shapeKey) {
        "circle" -> CircleShape
        "square" -> RoundedCornerShape(4.dp)
        else -> RoundedCornerShape(14.dp)
    }
    val sizeFrac = (p.appSizes[app.pkg]?.toFloatOrNull() ?: 1f).coerceIn(0.5f, 1f)

    val custom = p.customIcons[app.pkg]
    val bmp by produceState<ImageBitmap?>(null, app.pkg, custom, p.iconPack, banner) {
        value = IconCache.get(ctx, app.pkg, custom, p.iconPack, banner)
    }
    val cf = if (p.iconMono) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null

    Column(
        modifier,
        horizontalAlignment = if (banner) Alignment.Start else Alignment.CenterHorizontally
    ) {
        FocusBox(
            Modifier
                .fillMaxWidth(sizeFrac)
                .aspectRatio(if (banner) 16f / 9f else 1f),
            shape,
            p.focusScale,
            style = p.tileStyle,
            onClick = { openApp(vm, ctx, app) },
            onLongClick = { vm.menuApp = app }
        ) {
            bmp?.let { b ->
                val wide = b.width.toFloat() / b.height > 1.5f
                when {
                    banner && wide -> Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = cf)
                    banner -> Image(b, null, Modifier.fillMaxSize().padding(10.dp), contentScale = ContentScale.Fit, colorFilter = cf)
                    else -> Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = cf)
                }
            }
            if (app.pkg in p.locked) {
                Text("🔒", fontSize = 14.sp, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        Text(
            vm.labelOf(app),
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = if (banner) TextAlign.Start else TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface,
            style = shadowed(),
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 4.dp)
        )
    }
}
