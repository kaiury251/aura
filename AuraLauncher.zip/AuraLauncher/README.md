# Aura Launcher (Android TV)

Launcher original para Android TV / Google TV, feito do zero em Kotlin + Jetpack Compose.
Todas as funções são gratuitas. Não usa código nem recursos de outros apps.

## Como compilar e testar

1. Instale o **Android Studio** (versão Koala ou mais nova) no computador.
2. Abra a pasta `AuraLauncher` (File > Open). Se pedir para criar/atualizar o Gradle wrapper, aceite.
3. Aguarde o sync do Gradle (precisa de internet).
4. Ligue a TV com **depuração USB/ADB por rede** ativada, ou use o emulador "Android TV (1080p)".
   - TV: Configurações > Sobre > clique 7x em "Build" > Opções do desenvolvedor > Depuração USB.
   - Conecte: `adb connect IP_DA_TV:5555`
5. Clique em Run. Depois defina o Aura como tela inicial:
   Configurações > Apps > Apps padrão > Tela inicial (varia por TV).
   Ou, sem trocar o padrão, abra "Aura Launcher" pela lista de apps.

Se algo falhar, copie a mensagem de erro (Build ou Logcat) e envie.

## Funções

| Função | Onde |
|---|---|
| Cores dinâmicas a partir do papel de parede | Ajustes > Cores |
| Cor de destaque (8 presets + hexadecimal) | Ajustes > Cores |
| Linha de favoritos | Segure OK num app > Adicionar aos favoritos |
| Pastas | Segure OK > Mover para pasta |
| Todos os apps, ocultar apps | Segure OK > Ocultar / Ajustes > Apps ocultos |
| Renomear app, ícone personalizado | Segure OK num app |
| Papel de parede: imagem, vídeo, URL, posters de filmes | Ajustes > Papel de parede |
| Animações de abertura e de foco | Ajustes > Animações |
| Esconder itens quando ocioso | Ajustes > Animações |
| Até 4 perfis, cada um com layout, papel de parede e estilo | Topo da tela inicial |
| PIN por perfil | Ajustes > Perfil |
| Widgets: relógio, clima, notícias RSS/Atom | Ajustes > Widgets |
| Entradas HDMI | Linha "Entradas" |
| App de início automático | Ajustes > Apps |
| Backup e restauração | Ajustes > Backup |

Dica: se o controle não tiver clique longo, a tecla **Menu** abre as opções do app.

## Limitações conhecidas

- **Continue Assistindo / Watch Next e canais de TV ao vivo**: o Android só entrega esses dados a launchers do sistema. Não é possível ler no app comum.
- **Manter o Aura como tela inicial depois do botão Home em TVs que forçam o launcher original** (Fire TV, algumas Sony/Xiaomi): exige serviço de acessibilidade, que não está incluído.
- **Posters de filmes** precisam de uma chave gratuita da API do TMDB (themoviedb.org).
- O seletor de arquivos pode não existir em algumas TVs. Nesse caso use o endereço (URL) do papel de parede.
- O código ainda não foi compilado em aparelho. Podem aparecer erros de build ou ajustes de layout no primeiro teste.
