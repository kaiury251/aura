# Aura Launcher (Android TV)

Launcher original para Android TV / Google TV, feito do zero em Kotlin + Jetpack Compose.
Todas as funções são gratuitas. Não usa código nem recursos de outros apps.

## Como compilar sem computador

Envie este zip para o repositório do GitHub (Add file > Upload files). O workflow em
`.github/workflows/build.yml` compila sozinho e publica o `aura-launcher.apk` em Releases.

## Funções

| Função | Onde |
|---|---|
| Cores dinâmicas a partir do papel de parede, 8 cores prontas, cor em hexadecimal | Ajustes > Aparência |
| Liquid Glass (painéis e botões de vidro) | Ajustes > Aparência |
| Fonte do sistema (11 opções, com prévia) | Ajustes > Aparência |
| Papel de parede: imagem, vídeo, URL, posters de filmes (TMDB) | Ajustes > Papel de parede |
| Escurecer, desfoque (blur) e brilho do fundo | Ajustes > Papel de parede |
| Efeitos de chuva, neve e trovoada (manual ou automático pelo clima) | Ajustes > Efeitos climáticos |
| Estilo do bloco: padrão, transparente, cor uniforme, vidro | Ajustes > Blocos de apps |
| Formato dos ícones: banner, quadrado arredondado, redondo, quadrado | Ajustes > Blocos de apps |
| Tamanho dos ícones (geral e por app), ícones monocromáticos | Ajustes > Blocos de apps / segure OK |
| Pacotes de ícones externos (formato ADW/Nova) | Ajustes > Blocos de apps |
| Favoritos, pastas, ocultar, renomear, ícone personalizado | Segure OK num app |
| Bloqueio por PIN em apps individuais | Segure OK num app |
| Até 4 perfis, cada um com foto, layout, papel de parede e estilo | Topo da tela inicial |
| PIN por perfil | Ajustes > Perfil |
| Clima detalhado (7 dias): toque no widget de clima | Ajustes > Widgets |
| Central de notificações (sino) | Topo da tela inicial |
| Relógio, data, status da rede, Tocando agora, RSS/Atom | Ajustes > Widgets |
| Painel Bluetooth (listar, parear, remover) | Topo da tela inicial |
| Entradas HDMI, app de início automático, backup e restauração | Ajustes |

Dica: se o controle não tiver clique longo, a tecla **Menu** abre as opções do app.

## Permissões que o launcher pede

- **Acesso a notificações**: para o sino e o "Tocando agora". Ajustes > Widgets > "Acesso a notificações".
  Se a TV não tiver essa tela, use pelo ADB:
  `adb shell cmd notification allow_listener com.aura.launcher/com.aura.launcher.AuraNotifService`
- **Bluetooth**: pedida ao abrir o painel Bluetooth.

## Limitações conhecidas

- **Continue Assistindo / Watch Next e canais de TV ao vivo**: o Android só entrega esses dados a launchers do sistema.
- **Manter o Aura como tela inicial depois do botão Home em TVs que forçam o launcher original**: exige serviço de acessibilidade, que não está incluído.
- **Desfoque (blur)**: só funciona no Android 12 ou mais novo e não afeta papel de parede em vídeo.
- **Posters de filmes** precisam de uma chave gratuita da API do TMDB.
- **Remover pareamento Bluetooth** usa um recurso não oficial do Android. Se falhar, o app abre os ajustes do sistema.
- As funções novas desta versão ainda não foram testadas em aparelho.
