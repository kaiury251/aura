package com.aura.launcher

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.roundToInt

data class DayForecast(val label: String, val code: Int, val max: Int, val min: Int, val rain: Int)

data class WeatherData(
    val temp: Int,
    val feels: Int,
    val humidity: Int,
    val wind: Int,
    val code: Int,
    val days: List<DayForecast>
)

object Net {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 7000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AuraLauncher/1.1 RSS reader")
        c.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            stream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Clima atual e previsão de 7 dias via Open-Meteo (gratuito, sem chave). */
    suspend fun weatherFull(lat: Double, lon: Double): WeatherData? = withContext(Dispatchers.IO) {
        runCatching {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=7"
            val root = JSONObject(get(url))
            val cur = root.getJSONObject("current")
            val daily = root.getJSONObject("daily")
            val times = daily.getJSONArray("time")
            val codes = daily.getJSONArray("weather_code")
            val maxs = daily.getJSONArray("temperature_2m_max")
            val mins = daily.getJSONArray("temperature_2m_min")
            val rains = daily.optJSONArray("precipitation_probability_max")
            val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val out = SimpleDateFormat("EEE", Locale.getDefault())
            val days = (0 until times.length()).map { i ->
                val label = runCatching { out.format(parse.parse(times.getString(i))!!) }
                    .getOrDefault(times.getString(i))
                DayForecast(
                    label = label,
                    code = codes.getInt(i),
                    max = maxs.getDouble(i).roundToInt(),
                    min = mins.getDouble(i).roundToInt(),
                    rain = if (rains != null && !rains.isNull(i)) rains.getInt(i) else 0
                )
            }
            WeatherData(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                feels = cur.getDouble("apparent_temperature").roundToInt(),
                humidity = cur.getInt("relative_humidity_2m"),
                wind = cur.getDouble("wind_speed_10m").roundToInt(),
                code = cur.getInt("weather_code"),
                days = days
            )
        }.getOrNull()
    }

    suspend fun geocode(name: String): Triple<String, Double, Double>? = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(name, "UTF-8")
            val r = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=pt"))
                .getJSONArray("results").getJSONObject(0)
            Triple(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
        }.getOrNull()
    }

    /** Títulos de um feed RSS ou Atom. */
    suspend fun rss(url: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val xml = get(url)
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
            p.setInput(StringReader(xml))
            val titles = mutableListOf<String>()
            var inEntry = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && titles.size < 20) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name.substringAfter(':').lowercase()) {
                        "item", "entry" -> inEntry = true
                        "title" -> if (inEntry) {
                            val t = p.nextText().trim()
                            if (t.isNotEmpty()) titles.add(t)
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name.substringAfter(':').lowercase() in setOf("item", "entry")) {
                    inEntry = false
                }
                ev = p.next()
            }
            titles
        }.getOrElse { listOf("Falha ao carregar notícias. Verifique o feed e a conexão.") }
    }

    /** Imagens de fundo (backdrops) de filmes em alta. Precisa de chave gratuita do TMDB. */
    suspend fun posters(key: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val arr = JSONObject(
                get("https://api.themoviedb.org/3/trending/movie/week?api_key=$key&language=pt-BR")
            ).getJSONArray("results")
            (0 until arr.length()).mapNotNull {
                val path = arr.getJSONObject(it).optString("backdrop_path", "")
                if (path.isNotEmpty() && path != "null") "https://image.tmdb.org/t/p/w1280$path" else null
            }
        }.getOrDefault(emptyList())
    }
}

fun weatherEmoji(code: Int): String = when (code) {
    0 -> "☀️"
    1, 2 -> "🌤️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..67 -> "🌧️"
    in 71..77 -> "❄️"
    in 80..82 -> "🌦️"
    85, 86 -> "🌨️"
    in 95..99 -> "⛈️"
    else -> "🌡️"
}

fun weatherText(code: Int): String = when (code) {
    0 -> "Céu limpo"
    1, 2 -> "Poucas nuvens"
    3 -> "Nublado"
    45, 48 -> "Neblina"
    in 51..57 -> "Garoa"
    in 61..67 -> "Chuva"
    in 71..77 -> "Neve"
    in 80..82 -> "Pancadas de chuva"
    85, 86 -> "Pancadas de neve"
    in 95..99 -> "Tempestade"
    else -> "—"
}

/** Efeito visual correspondente a um código de clima (WMO): rain | snow | storm | none. */
fun fxKindFor(code: Int): String = when (code) {
    in 51..67, in 80..82 -> "rain"
    in 71..77, 85, 86 -> "snow"
    in 95..99 -> "storm"
    else -> "none"
}
